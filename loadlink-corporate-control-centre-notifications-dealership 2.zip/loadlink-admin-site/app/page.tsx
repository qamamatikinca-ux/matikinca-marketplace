"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { browserConfigured, browserSupabase } from "@/lib/supabaseBrowser";

type Moderation = {
  status: string;
  reason?: string | null;
  internal_notes?: string | null;
  strike_count?: number;
  suspended_until?: string | null;
};

type UserRow = {
  id: string;
  email: string;
  name: string;
  createdAt: string;
  lastSignInAt?: string | null;
  listingsCount: number;
  moderation: Moderation;
  team?: TeamRow | null;
};

type TeamRow = {
  user_id: string;
  email: string;
  display_name?: string | null;
  role: string;
  department?: string | null;
  is_active: boolean;
  last_seen_at?: string | null;
  created_at: string;
};

type TaskRow = {
  id: string;
  title: string;
  description?: string | null;
  department?: string | null;
  priority: string;
  status: string;
  assigned_to?: string | null;
  due_at?: string | null;
  created_at: string;
};

type ListingRow = {
  id: string;
  title: string;
  city: string;
  posted_by: string;
  package_type: string;
  status: string;
  moderation_status: string;
  moderation_notes?: string | null;
  created_at: string;
  user_id?: string | null;
  photos?: string[] | null;
};

type VerificationRow = {
  id: string;
  listing_id: string;
  user_id: string;
  status: string;
  reviewer_notes?: string | null;
  dealership_application?: boolean | null;
  dealership_name?: string | null;
  company_registration_number?: string | null;
  tax_number?: string | null;
  created_at: string;
};

type PaymentRow = {
  id: string;
  user_id?: string | null;
  listing_id?: string | null;
  amount_cents: number;
  currency: string;
  status: string;
  provider: string;
  reference: string;
  external_reference?: string | null;
  provider_transaction_id?: string | null;
  payment_method?: string | null;
  payer_email?: string | null;
  description?: string | null;
  reconciliation_status?: string | null;
  reconciled_at?: string | null;
  due_at?: string | null;
  settled_at?: string | null;
  refunded_at?: string | null;
  refund_reference?: string | null;
  receipt_url?: string | null;
  notes?: string | null;
  created_at: string;
  updated_at?: string | null;
};

type ReportRow = {
  id: string;
  reported_user_id?: string | null;
  listing_id?: string | null;
  category: string;
  details?: string | null;
  status: string;
  assigned_to?: string | null;
  resolution_notes?: string | null;
  created_at: string;
};

type AuditRow = {
  id: string;
  admin_user_id?: string | null;
  action: string;
  entity_type: string;
  entity_id?: string | null;
  metadata?: Record<string, unknown>;
  created_at: string;
};

type BackupRow = {
  id: string;
  backup_reference: string;
  status: string;
  trigger_source: string;
  object_path?: string | null;
  size_bytes?: number | null;
  sha256?: string | null;
  table_counts?: Record<string, number> | null;
  included_resources?: string[] | null;
  failure_message?: string | null;
  started_at: string;
  completed_at?: string | null;
  expires_at?: string | null;
  created_at: string;
};

type NotificationRow = {
  id: string;
  title: string;
  body?: string | null;
  severity: string;
  category: string;
  is_read: boolean;
  created_at: string;
};

type SystemInfo = {
  mfaRequired: boolean;
  cronConfigured: boolean;
  paymentWebhookConfigured: boolean;
  backupRetentionDays: number;
  secretKeyServerOnly: boolean;
  latestBackupAt?: string | null;
  latestBackupReference?: string | null;
  backupBucketPrivate: boolean;
  autoRefreshMinutes: number;
};

type Overview = {
  generatedAt: string;
  currentAdmin: TeamRow;
  metrics: Record<string, number>;
  users: UserRow[];
  listings: ListingRow[];
  verifications: VerificationRow[];
  payments: PaymentRow[];
  team: TeamRow[];
  tasks: TaskRow[];
  reports: ReportRow[];
  backups: BackupRow[];
  notifications: NotificationRow[];
  settings: Array<{ key: string; value: Record<string, unknown>; updated_at: string }>;
  audit: AuditRow[];
  system: SystemInfo;
};

type Tab =
  | "overview"
  | "queue"
  | "moderation"
  | "users"
  | "verifications"
  | "reports"
  | "finance"
  | "team"
  | "tasks"
  | "backups"
  | "audit"
  | "security";

type RequestFn = (
  path: string,
  method: "POST" | "PATCH" | "DELETE",
  body?: Record<string, unknown>,
) => Promise<unknown>;

const navGroups: Array<{ label: string; items: Array<{ id: Tab; label: string }> }> = [
  {
    label: "Control",
    items: [
      { id: "overview", label: "Overview" },
      { id: "queue", label: "Work queue" },
    ],
  },
  {
    label: "Website operations",
    items: [
      { id: "moderation", label: "Listings" },
      { id: "users", label: "Users" },
      { id: "verifications", label: "Applications" },
      { id: "reports", label: "Reports" },
    ],
  },
  {
    label: "Business operations",
    items: [
      { id: "finance", label: "Finance" },
      { id: "team", label: "Team" },
      { id: "tasks", label: "Tasks" },
    ],
  },
  {
    label: "Governance",
    items: [
      { id: "backups", label: "Backups" },
      { id: "audit", label: "Audit log" },
      { id: "security", label: "Security" },
    ],
  },
];

const allTabs = navGroups.flatMap((group) => group.items);

export default function AdminPage() {
  const [sessionReady, setSessionReady] = useState(false);
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [data, setData] = useState<Overview | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  useEffect(() => {
    const authError = new URLSearchParams(window.location.search).get("auth_error");
    if (authError) {
      queueMicrotask(() => setMessage(authError));
      window.history.replaceState({}, "", window.location.pathname);
    }

    if (!browserConfigured) {
      queueMicrotask(() => setSessionReady(true));
      return;
    }

    browserSupabase.auth.getSession().then(({ data: session, error }) => {
      if (error) setMessage(error.message);
      setToken(session.session?.access_token || "");
      setSessionReady(true);
    });

    const {
      data: { subscription },
    } = browserSupabase.auth.onAuthStateChange((_event, session) => {
      setToken(session?.access_token || "");
    });

    return () => subscription.unsubscribe();
  }, []);

  const load = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    setMessage("");
    try {
      const response = await fetch("/api/admin/overview", {
        cache: "no-store",
        headers: { Authorization: `Bearer ${token}` },
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Could not load dashboard.");
      setData(payload);
      setLastRefresh(new Date());
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not load dashboard.");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (!token) return;
    queueMicrotask(() => void load());
    const timer = window.setInterval(() => void load(), 10 * 60 * 1000);
    return () => window.clearInterval(timer);
  }, [token, load]);

  const request: RequestFn = useCallback(
    async (path, method, body = {}) => {
      setLoading(true);
      setMessage("");
      try {
        const response = await fetch(path, {
          method,
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: method === "DELETE" ? undefined : JSON.stringify(body),
        });
        const payload = await response.json();
        if (!response.ok) throw new Error(payload.error || "Action failed.");
        await load();
        return payload;
      } catch (error) {
        setMessage(error instanceof Error ? error.message : "Action failed.");
        throw error;
      } finally {
        setLoading(false);
      }
    },
    [load, token],
  );

  async function signIn() {
    setMessage("");
    const { error } = await browserSupabase.auth.signInWithPassword({ email, password });
    if (error) setMessage(error.message);
  }

  async function googleSignIn() {
    setMessage("");
    const callbackUrl = `${window.location.origin}/auth/callback`;
    const { error } = await browserSupabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: callbackUrl,
        queryParams: { prompt: "select_account" },
      },
    });

    if (error) setMessage(error.message);
  }

  if (!sessionReady) return <Loading />;
  if (!token) {
    return (
      <Login
        email={email}
        password={password}
        setEmail={setEmail}
        setPassword={setPassword}
        signIn={signIn}
        googleSignIn={googleSignIn}
        message={message}
      />
    );
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brandMark">L</span>
          <div>
            <strong>LoadLink</strong>
            <small>Organisation control</small>
          </div>
        </div>

        <nav className="navigation">
          {navGroups.map((group) => (
            <section className="navGroup" key={group.label}>
              <p>{group.label}</p>
              <div>
                {group.items.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setTab(item.id)}
                    className={tab === item.id ? "active" : ""}
                  >
                    {item.label}
                    {item.id === "queue" && data ? <span>{queueCount(data)}</span> : null}
                  </button>
                ))}
              </div>
            </section>
          ))}
        </nav>

        <div className="adminIdentity">
          <small>Signed in as</small>
          <strong>{data?.currentAdmin?.display_name || data?.currentAdmin?.email || "Administrator"}</strong>
          <span>{data?.currentAdmin?.role || "admin"}</span>
        </div>
        <button className="signout" onClick={() => browserSupabase.auth.signOut()}>
          Sign out
        </button>
      </aside>

      <section className="content">
        <header className="topbar">
          <div>
            <p>LOADLINK ORGANISATION CONTROL CENTRE</p>
            <h1>{allTabs.find((item) => item.id === tab)?.label}</h1>
          </div>
          <div className="refreshBlock">
            <span className="systemState"><i /> Live operational data</span>
            <small>Automatic refresh every 10 minutes</small>
            <button onClick={() => void load()} disabled={loading}>
              {loading ? "Refreshing…" : "Refresh now"}
            </button>
          </div>
        </header>

        {message ? <div className="error">{message}</div> : null}
        {!data ? (
          <Loading />
        ) : (
          <Dashboard tab={tab} data={data} request={request} token={token} />
        )}
        <footer>
          Last refreshed: {lastRefresh?.toLocaleString() || "—"} · Generated by the private admin server
        </footer>
      </section>
    </main>
  );
}

function Dashboard({
  tab,
  data,
  request,
  token,
}: {
  tab: Tab;
  data: Overview;
  request: RequestFn;
  token: string;
}) {
  if (tab === "overview") return <OverviewTab data={data} request={request} />;
  if (tab === "queue") return <WorkQueue data={data} request={request} />;
  if (tab === "moderation") return <Panel title="Listing moderation"><Listings rows={data.listings} request={request} /></Panel>;
  if (tab === "users") return <UsersTab rows={data.users} request={request} />;
  if (tab === "verifications") return <Panel title="Identity and vehicle applications"><Applications rows={data.verifications} request={request} /></Panel>;
  if (tab === "reports") return <ReportsTab rows={data.reports} team={data.team} request={request} />;
  if (tab === "finance") return <FinanceTab rows={data.payments} metrics={data.metrics} request={request} token={token} />;
  if (tab === "team") return <TeamTab rows={data.team} request={request} />;
  if (tab === "tasks") return <TasksTab rows={data.tasks} team={data.team} request={request} />;
  if (tab === "backups") return <BackupsTab rows={data.backups} system={data.system} request={request} token={token} />;
  if (tab === "security") return <SecurityTab data={data} />;
  return <Audit rows={data.audit} team={data.team} />;
}

function OverviewTab({ data, request }: { data: Overview; request: RequestFn }) {
  const m = data.metrics;
  const latestBackup = data.backups.find((item) => item.status === "completed");
  return (
    <>
      <div className="metrics">
        <Metric label="Registered users" value={m.totalUsers || 0} />
        <Metric label="Pending listings" value={m.pendingListings || 0} urgent={Boolean(m.pendingListings)} />
        <Metric label="Applications" value={m.pendingVerifications || 0} urgent={Boolean(m.pendingVerifications)} />
        <Metric label="Open reports" value={m.openReports || 0} urgent={Boolean(m.openReports)} />
        <Metric label="Paid revenue" value={money(m.paidCents || 0)} />
        <Metric label="Pending payments" value={money(m.pendingCents || 0)} urgent={Boolean(m.pendingCents)} />
        <Metric label="Unreconciled" value={m.unreconciledPayments || 0} urgent={Boolean(m.unreconciledPayments)} />
        <Metric label="Open tasks" value={m.openTasks || 0} />
        <Metric label="Overdue tasks" value={m.overdueTasks || 0} urgent={Boolean(m.overdueTasks)} />
        <Metric label="Active team" value={m.teamMembers || 0} />
        <Metric label="Cloud backups" value={m.backupCount || 0} />
        <Metric label="Last backup" value={latestBackup ? relativeDate(latestBackup.completed_at) : "Not created"} urgent={!latestBackup} />
      </div>

      <div className="overviewGrid">
        <Panel title="Priority work">
          <Tasks
            rows={data.tasks
              .filter((row) => ["urgent", "high"].includes(row.priority) && !["done", "cancelled"].includes(row.status))
              .slice(0, 8)}
            team={data.team}
            request={request}
          />
        </Panel>
        <Panel title="Finance attention">
          <FinanceAttention rows={data.payments} />
        </Panel>
      </div>

      <Panel title="Newest listings awaiting approval">
        <Listings rows={data.listings.filter((row) => row.moderation_status === "pending").slice(0, 8)} request={request} />
      </Panel>

      {data.notifications.length ? (
        <Panel title="Organisation alerts">
          <div className="alertList">
            {data.notifications.slice(0, 8).map((item) => (
              <article key={item.id} className={`alertItem ${item.severity}`}>
                <Status value={item.severity} />
                <div>
                  <strong>{item.title}</strong>
                  <p>{item.body || item.category}</p>
                </div>
                <small>{dateTime(item.created_at)}</small>
              </article>
            ))}
          </div>
        </Panel>
      ) : null}
    </>
  );
}

function WorkQueue({ data, request }: { data: Overview; request: RequestFn }) {
  const pendingListings = data.listings.filter((row) => row.moderation_status === "pending");
  const pendingApplications = data.verifications.filter((row) => ["pending", "under_review"].includes(row.status));
  const openReports = data.reports.filter((row) => ["open", "reviewing"].includes(row.status));
  const financeIssues = data.payments.filter((row) => row.reconciliation_status !== "reconciled" || row.status === "failed");
  const overdue = data.tasks.filter((row) => row.due_at && new Date(row.due_at) < new Date() && !["done", "cancelled"].includes(row.status));

  return (
    <div className="queueGrid">
      <QueuePanel title="Listings awaiting approval" count={pendingListings.length}>
        <Listings rows={pendingListings.slice(0, 10)} request={request} />
      </QueuePanel>
      <QueuePanel title="Applications requiring review" count={pendingApplications.length}>
        <Applications rows={pendingApplications.slice(0, 10)} request={request} />
      </QueuePanel>
      <QueuePanel title="Open reports" count={openReports.length}>
        <Reports rows={openReports.slice(0, 10)} team={data.team} request={request} />
      </QueuePanel>
      <QueuePanel title="Finance exceptions" count={financeIssues.length}>
        <FinanceAttention rows={financeIssues.slice(0, 10)} />
      </QueuePanel>
      <QueuePanel title="Overdue tasks" count={overdue.length}>
        <Tasks rows={overdue} team={data.team} request={request} />
      </QueuePanel>
    </div>
  );
}

function Listings({ rows, request }: { rows: ListingRow[]; request: RequestFn }) {
  return (
    <div className="cards">
      {rows.length ? rows.map((row) => (
        <article className="card" key={row.id}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={row.photos?.[0] || "/placeholder.svg"} alt="" />
          <div className="cardBody">
            <div className="row">
              <Status value={row.moderation_status || "pending"} />
              <small>{row.package_type || "standard"}</small>
            </div>
            <h3>{row.title}</h3>
            <p>{row.city} · {row.posted_by}</p>
            <small>{date(row.created_at)}</small>
            {row.moderation_notes ? <span className="subline">Note: {row.moderation_notes}</span> : null}
            <div className="actions">
              <button onClick={() => moderateListing(row.id, "approved", request)}>Approve</button>
              <button className="danger" onClick={() => moderateListing(row.id, "rejected", request)}>Reject</button>
              <button className="ghost" onClick={() => moderateListing(row.id, "pending", request)}>Return to review</button>
            </div>
          </div>
        </article>
      )) : <Empty />}
    </div>
  );
}

async function moderateListing(id: string, status: string, request: RequestFn) {
  const notes = status === "approved"
    ? ""
    : window.prompt(status === "rejected" ? "Reason shown to the user" : "Reason for returning this post to review") || "";
  if (status !== "approved" && notes.trim().length < 3) return;
  await request(`/api/admin/listings/${id}`, "PATCH", { status, notes });
}

function UsersTab({ rows, request }: { rows: UserRow[]; request: RequestFn }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const visible = useMemo(() => rows.filter((row) => {
    const matches = `${row.email} ${row.name}`.toLowerCase().includes(query.toLowerCase());
    return matches && (filter === "all" || row.moderation.status === filter);
  }), [filter, query, rows]);

  return (
    <Panel title="User control and risk management">
      <div className="panelTools multi">
        <input placeholder="Search name or email" value={query} onChange={(event) => setQuery(event.target.value)} />
        <select value={filter} onChange={(event) => setFilter(event.target.value)}>
          {[
            ["all", "All users"],
            ["active", "Active"],
            ["flagged", "Flagged"],
            ["suspended", "Suspended"],
            ["blocked", "Blocked"],
          ].map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
      </div>
      <div className="tableWrap">
        <table>
          <thead><tr><th>User</th><th>Status</th><th>Listings</th><th>Joined</th><th>Last sign in</th><th>Controls</th></tr></thead>
          <tbody>
            {visible.map((row) => (
              <tr key={row.id}>
                <td><strong>{row.name || "Unnamed user"}</strong><span className="subline">{row.email}</span></td>
                <td><Status value={row.moderation.status || "active"} />{row.moderation.reason ? <span className="subline">{row.moderation.reason}</span> : null}</td>
                <td>{row.listingsCount}</td>
                <td>{date(row.createdAt)}</td>
                <td>{date(row.lastSignInAt)}</td>
                <td>
                  <div className="inlineActions">
                    <button className="warning" onClick={() => userAction(row.id, "flagged", request)}>Flag</button>
                    <button className="ghost" onClick={() => userAction(row.id, "suspended", request)}>Suspend</button>
                    <button className="danger" onClick={() => userAction(row.id, "blocked", request)}>Block</button>
                    {row.moderation.status !== "active" ? <button onClick={() => userAction(row.id, "active", request)}>Restore</button> : null}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {visible.length ? null : <Empty />}
      </div>
    </Panel>
  );
}

async function userAction(id: string, status: string, request: RequestFn) {
  const reason = status === "active" ? "Account access restored." : window.prompt("Reason shown to the user") || "";
  if (status !== "active" && reason.trim().length < 3) return;
  const notes = status === "active" ? "" : window.prompt("Private internal notes (optional)") || "";
  const suspendDays = status === "suspended" ? Number(window.prompt("Number of suspension days", "7") || 7) : 0;
  const rejectListings = status === "blocked" ? window.confirm("Also reject all listings from this account?") : false;
  await request(`/api/admin/users/${id}`, "PATCH", { status, reason, notes, suspendDays, rejectListings });
}

function Applications({ rows, request }: { rows: VerificationRow[]; request: RequestFn }) {
  const [documentLinks, setDocumentLinks] = useState<Record<string, Array<{ label: string; url: string }>>>({});

  async function loadDocuments(id: string) {
    const payload = await request(`/api/admin/verifications/${id}/documents`, "POST") as { documents?: Array<{ label: string; url: string }> };
    setDocumentLinks((current) => ({ ...current, [id]: payload.documents || [] }));
  }

  return (
    <div className="tableWrap">
      <table>
        <thead><tr><th>Application</th><th>Listing</th><th>User</th><th>Type</th><th>Status</th><th>Received</th><th>Decision</th></tr></thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id}>
              <td>
                <code>{row.id.slice(0, 12)}</code>
                {row.dealership_name ? <span className="subline">{row.dealership_name}</span> : null}
                {row.company_registration_number ? <span className="subline">CIPC: {row.company_registration_number}</span> : null}
              </td>
              <td><code>{row.listing_id?.slice(0, 12) || "—"}</code></td>
              <td><code>{row.user_id?.slice(0, 12) || "—"}</code></td>
              <td><Status value={row.dealership_application ? "dealership" : "private"} />{row.tax_number ? <span className="subline">Tax: {row.tax_number}</span> : null}</td>
              <td><Status value={row.status} />{row.reviewer_notes ? <span className="subline">{row.reviewer_notes}</span> : null}</td>
              <td>{date(row.created_at)}</td>
              <td>
                <div className="inlineActions">
                  <button className="ghost" onClick={() => loadDocuments(row.id)}>Documents</button>
                  <button onClick={() => verificationAction(row.id, "verified", request)}>Accept</button>
                  <button className="danger" onClick={() => verificationAction(row.id, "rejected", request)}>Reject</button>
                  <button className="ghost" onClick={() => verificationAction(row.id, "more_information_required", request)}>Request info</button>
                </div>
                {documentLinks[row.id]?.length ? (
                  <div className="documentLinks">
                    {documentLinks[row.id].map((document) => <a key={document.label} href={document.url} target="_blank" rel="noreferrer">{document.label}</a>)}
                  </div>
                ) : null}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length ? null : <Empty />}
    </div>
  );
}
async function verificationAction(id: string, status: string, request: RequestFn) {
  const notes = window.prompt("Review note (optional)") || "";
  await request(`/api/admin/verifications/${id}`, "PATCH", { status, notes });
}

function ReportsTab({ rows, team, request }: { rows: ReportRow[]; team: TeamRow[]; request: RequestFn }) {
  return <Panel title="Trust and safety reports"><Reports rows={rows} team={team} request={request} /></Panel>;
}

function Reports({ rows, team, request }: { rows: ReportRow[]; team: TeamRow[]; request: RequestFn }) {
  return (
    <div className="tableWrap">
      <table>
        <thead><tr><th>Category</th><th>Target</th><th>Details</th><th>Status</th><th>Assigned</th><th>Created</th><th>Action</th></tr></thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id}>
              <td><strong>{row.category.replaceAll("_", " ")}</strong></td>
              <td>{row.listing_id ? `Listing ${row.listing_id.slice(0, 8)}` : row.reported_user_id ? `User ${row.reported_user_id.slice(0, 8)}` : "General"}</td>
              <td>{row.details || "No details supplied"}</td>
              <td><Status value={row.status} /></td>
              <td>{team.find((member) => member.user_id === row.assigned_to)?.display_name || "Unassigned"}</td>
              <td>{date(row.created_at)}</td>
              <td>
                <div className="inlineActions">
                  <button className="ghost" onClick={() => reportAction(row.id, "reviewing", request)}>Review</button>
                  <button onClick={() => reportAction(row.id, "resolved", request)}>Resolve</button>
                  <button className="danger" onClick={() => reportAction(row.id, "dismissed", request)}>Dismiss</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length ? null : <Empty />}
    </div>
  );
}

async function reportAction(id: string, status: string, request: RequestFn) {
  const notes = window.prompt("Resolution or review notes (optional)") || "";
  await request(`/api/admin/reports/${id}`, "PATCH", { status, notes });
}

function FinanceTab({
  rows,
  metrics,
  request,
  token,
}: {
  rows: PaymentRow[];
  metrics: Record<string, number>;
  request: RequestFn;
  token: string;
}) {
  const [amount, setAmount] = useState("");
  const [payerEmail, setPayerEmail] = useState("");
  const [provider, setProvider] = useState("manual");
  const [paymentMethod, setPaymentMethod] = useState("bank_transfer");
  const [externalReference, setExternalReference] = useState("");
  const [providerTransactionId, setProviderTransactionId] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState("pending");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [reconciliationFilter, setReconciliationFilter] = useState("all");

  const visible = useMemo(() => rows.filter((row) => {
    const haystack = `${row.reference} ${row.external_reference || ""} ${row.provider_transaction_id || ""} ${row.payer_email || ""} ${row.provider}`.toLowerCase();
    return haystack.includes(search.toLowerCase())
      && (statusFilter === "all" || row.status === statusFilter)
      && (reconciliationFilter === "all" || row.reconciliation_status === reconciliationFilter);
  }), [reconciliationFilter, rows, search, statusFilter]);

  async function createPayment() {
    if (!amount) return;
    await request("/api/admin/payments", "POST", {
      amount,
      payerEmail,
      provider,
      paymentMethod,
      externalReference,
      providerTransactionId,
      description,
      status,
    });
    setAmount("");
    setExternalReference("");
    setProviderTransactionId("");
    setDescription("");
  }

  async function exportPayments() {
    const response = await fetch("/api/admin/payments/export", { headers: { Authorization: `Bearer ${token}` } });
    if (!response.ok) return;
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `loadlink-payments-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <>
      <div className="metrics financeMetrics">
        <Metric label="Paid revenue" value={money(metrics.paidCents || 0)} />
        <Metric label="Pending value" value={money(metrics.pendingCents || 0)} urgent={Boolean(metrics.pendingCents)} />
        <Metric label="Refunded" value={money(metrics.refundedCents || 0)} />
        <Metric label="Unreconciled" value={metrics.unreconciledPayments || 0} urgent={Boolean(metrics.unreconciledPayments)} />
        <Metric label="Disputed" value={metrics.disputedPayments || 0} urgent={Boolean(metrics.disputedPayments)} />
        <Metric label="Transactions" value={metrics.paymentCount || rows.length} />
      </div>

      <Panel title="Record a payment">
        <div className="formGrid financeForm">
          <input type="number" min="0" step="0.01" placeholder="Amount in rand" value={amount} onChange={(event) => setAmount(event.target.value)} />
          <input type="email" placeholder="Payer email" value={payerEmail} onChange={(event) => setPayerEmail(event.target.value)} />
          <select value={provider} onChange={(event) => setProvider(event.target.value)}>
            {[
              ["manual", "Manual entry"],
              ["paystack", "Paystack"],
              ["payfast", "PayFast"],
              ["yoco", "Yoco"],
              ["stripe", "Stripe"],
              ["bank", "Bank"],
              ["other", "Other"],
            ].map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
          <select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value)}>
            {[
              ["bank_transfer", "Bank transfer"],
              ["card", "Card"],
              ["eft", "EFT"],
              ["cash", "Cash"],
              ["wallet", "Wallet"],
              ["other", "Other"],
            ].map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
          <input placeholder="Provider / bank reference" value={externalReference} onChange={(event) => setExternalReference(event.target.value)} />
          <input placeholder="Provider transaction ID" value={providerTransactionId} onChange={(event) => setProviderTransactionId(event.target.value)} />
          <input placeholder="Description" value={description} onChange={(event) => setDescription(event.target.value)} />
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            {[
              ["pending", "Pending"],
              ["paid", "Paid"],
              ["failed", "Failed"],
              ["cancelled", "Cancelled"],
            ].map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select>
          <button onClick={() => void createPayment()}>Create payment record</button>
        </div>
        <p className="helper">A unique internal reference such as LL-PAY-20260713-100001 is generated automatically. Keep provider references separate for bank and gateway reconciliation.</p>
      </Panel>

      <Panel title="Payment ledger">
        <div className="panelTools paymentTools">
          <input placeholder="Search reference, payer or provider" value={search} onChange={(event) => setSearch(event.target.value)} />
          <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
            <option value="all">All statuses</option>
            {["pending", "paid", "failed", "refunded", "cancelled"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <select value={reconciliationFilter} onChange={(event) => setReconciliationFilter(event.target.value)}>
            <option value="all">All reconciliation</option>
            {["unmatched", "matched", "reconciled", "disputed"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <button onClick={() => void exportPayments()}>Export CSV</button>
        </div>
        <Payments rows={visible} request={request} />
      </Panel>
    </>
  );
}

function Payments({ rows, request }: { rows: PaymentRow[]; request: RequestFn }) {
  return (
    <div className="tableWrap">
      <table className="paymentsTable">
        <thead>
          <tr>
            <th>Internal reference</th><th>Provider reference</th><th>Payer</th><th>Status</th><th>Reconciliation</th><th>Amount</th><th>Date</th><th>Controls</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id}>
              <td>
                <button className="referenceButton" onClick={() => navigator.clipboard.writeText(row.reference)}>{row.reference}</button>
                <span className="subline">{row.provider} · {row.payment_method || "method not recorded"}</span>
              </td>
              <td>{row.external_reference || row.provider_transaction_id || "—"}{row.provider_transaction_id && row.external_reference ? <span className="subline">{row.provider_transaction_id}</span> : null}</td>
              <td>{row.payer_email || "—"}<span className="subline">{row.description || "No description"}</span></td>
              <td><Status value={row.status} /></td>
              <td><Status value={row.reconciliation_status || "unmatched"} />{row.reconciled_at ? <span className="subline">{date(row.reconciled_at)}</span> : null}</td>
              <td><strong>{money(row.amount_cents, row.currency)}</strong></td>
              <td>{date(row.created_at)}</td>
              <td>
                <div className="inlineActions">
                  {row.status !== "paid" ? <button onClick={() => request(`/api/admin/payments/${row.id}`, "PATCH", { status: "paid" })}>Mark paid</button> : null}
                  {row.reconciliation_status !== "reconciled" ? <button className="ghost" onClick={() => request(`/api/admin/payments/${row.id}`, "PATCH", { reconciliationStatus: "reconciled" })}>Reconcile</button> : null}
                  {row.reconciliation_status !== "disputed" ? <button className="warning" onClick={() => request(`/api/admin/payments/${row.id}`, "PATCH", { reconciliationStatus: "disputed" })}>Dispute</button> : null}
                  {row.status === "paid" ? <button className="danger" onClick={() => paymentRefund(row, request)}>Refund</button> : null}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length ? null : <Empty />}
    </div>
  );
}

async function paymentRefund(row: PaymentRow, request: RequestFn) {
  const refundReference = window.prompt("Refund reference or bank transaction number") || "";
  const notes = window.prompt("Refund reason") || "";
  if (!window.confirm(`Mark ${row.reference} as refunded?`)) return;
  await request(`/api/admin/payments/${row.id}`, "PATCH", {
    status: "refunded",
    refundReference,
    notes,
    reconciliationStatus: "reconciled",
  });
}

function FinanceAttention({ rows }: { rows: PaymentRow[] }) {
  const attention = rows.filter((row) => row.status === "failed" || row.reconciliation_status !== "reconciled").slice(0, 10);
  return (
    <div className="compactList">
      {attention.length ? attention.map((row) => (
        <article key={row.id}>
          <div>
            <strong>{row.reference || row.id.slice(0, 8)}</strong>
            <span>{row.payer_email || row.provider}</span>
          </div>
          <Status value={row.reconciliation_status || row.status} />
          <b>{money(row.amount_cents, row.currency)}</b>
        </article>
      )) : <Empty />}
    </div>
  );
}

function TeamTab({ rows, request }: { rows: TeamRow[]; request: RequestFn }) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("viewer");
  const [department, setDepartment] = useState("Operations");

  return (
    <>
      <Panel title="Add team member">
        <div className="formGrid">
          <input placeholder="Team member email" value={email} onChange={(event) => setEmail(event.target.value)} />
          <input placeholder="Display name" value={name} onChange={(event) => setName(event.target.value)} />
          <select value={role} onChange={(event) => setRole(event.target.value)}>
            {["admin", "operations", "moderator", "verification", "finance", "support", "analyst", "viewer"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <input placeholder="Department" value={department} onChange={(event) => setDepartment(event.target.value)} />
          <button onClick={() => request("/api/admin/team", "POST", { email, displayName: name, role, department })}>Add member</button>
        </div>
        <p className="helper">The person must first create a normal LoadLink account using this email. Add only the role and permissions they need.</p>
      </Panel>
      <Panel title="Organisation team">
        <div className="teamGrid">
          {rows.map((row) => (
            <article className="teamCard" key={row.user_id}>
              <div className="avatar">{(row.display_name || row.email).slice(0, 1).toUpperCase()}</div>
              <div>
                <h3>{row.display_name || row.email}</h3>
                <p>{row.email}</p>
                <span>{row.department || "No department"}</span>
                <small className="subline">Last active: {dateTime(row.last_seen_at)}</small>
              </div>
              <div className="teamActions">
                <Status value={row.is_active ? row.role : "inactive"} />
                {row.role !== "owner" ? (
                  <button className="ghost" onClick={() => request("/api/admin/team", "PATCH", { userId: row.user_id, isActive: !row.is_active })}>
                    {row.is_active ? "Deactivate" : "Reactivate"}
                  </button>
                ) : null}
              </div>
            </article>
          ))}
        </div>
      </Panel>
    </>
  );
}

function TasksTab({ rows, team, request }: { rows: TaskRow[]; team: TeamRow[]; request: RequestFn }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [assignedTo, setAssignedTo] = useState("");
  const [priority, setPriority] = useState("normal");
  const [department, setDepartment] = useState("Operations");
  const [dueAt, setDueAt] = useState("");

  return (
    <>
      <Panel title="Create and assign task">
        <div className="formGrid">
          <input placeholder="Task title" value={title} onChange={(event) => setTitle(event.target.value)} />
          <input placeholder="Description" value={description} onChange={(event) => setDescription(event.target.value)} />
          <select value={assignedTo} onChange={(event) => setAssignedTo(event.target.value)}>
            <option value="">Unassigned</option>
            {team.filter((member) => member.is_active).map((member) => <option key={member.user_id} value={member.user_id}>{member.display_name || member.email}</option>)}
          </select>
          <select value={priority} onChange={(event) => setPriority(event.target.value)}>
            {["low", "normal", "high", "urgent"].map((item) => <option key={item}>{item}</option>)}
          </select>
          <input placeholder="Department" value={department} onChange={(event) => setDepartment(event.target.value)} />
          <input type="datetime-local" value={dueAt} onChange={(event) => setDueAt(event.target.value)} />
          <button onClick={() => request("/api/admin/tasks", "POST", { title, description, assignedTo: assignedTo || null, priority, department, dueAt: dueAt ? new Date(dueAt).toISOString() : null })}>Create task</button>
        </div>
      </Panel>
      <Panel title="Team work board"><Tasks rows={rows} team={team} request={request} /></Panel>
    </>
  );
}

function Tasks({ rows, team, request }: { rows: TaskRow[]; team: TeamRow[]; request: RequestFn }) {
  const columns = ["todo", "in_progress", "review", "blocked", "done"];
  return (
    <div className="taskBoard">
      {columns.map((column) => (
        <section className="taskColumn" key={column}>
          <h3>{column.replaceAll("_", " ")} <span>{rows.filter((row) => row.status === column).length}</span></h3>
          {rows.filter((row) => row.status === column).map((row) => (
            <article className={`taskCard ${row.priority}`} key={row.id}>
              <div className="row"><Status value={row.priority} /><small>{row.department || "General"}</small></div>
              <h4>{row.title}</h4>
              <p>{row.description || "No description"}</p>
              <small>{row.assigned_to ? team.find((member) => member.user_id === row.assigned_to)?.display_name || team.find((member) => member.user_id === row.assigned_to)?.email : "Unassigned"}</small>
              {row.due_at ? <small className={new Date(row.due_at) < new Date() && row.status !== "done" ? "overdue" : ""}>Due {date(row.due_at)}</small> : null}
              <select value={row.status} onChange={(event) => request(`/api/admin/tasks/${row.id}`, "PATCH", { status: event.target.value })}>
                {columns.concat("cancelled").map((item) => <option key={item} value={item}>{item.replaceAll("_", " ")}</option>)}
              </select>
            </article>
          ))}
        </section>
      ))}
    </div>
  );
}

function BackupsTab({
  rows,
  system,
  request,
  token,
}: {
  rows: BackupRow[];
  system: SystemInfo;
  request: RequestFn;
  token: string;
}) {
  const latest = rows.find((row) => row.status === "completed");

  async function downloadBackup(id: string) {
    const response = await fetch(`/api/admin/backups/${id}`, { headers: { Authorization: `Bearer ${token}` } });
    const payload = await response.json();
    if (response.ok && payload.url) window.location.assign(payload.url);
  }

  return (
    <>
      <div className="metrics backupMetrics">
        <Metric label="Last completed" value={latest ? relativeDate(latest.completed_at) : "None"} urgent={!latest} />
        <Metric label="Completed snapshots" value={rows.filter((row) => row.status === "completed").length} />
        <Metric label="Failed snapshots" value={rows.filter((row) => row.status === "failed").length} urgent={rows.some((row) => row.status === "failed")} />
        <Metric label="Retention" value={`${system.backupRetentionDays || 30} days`} />
        <Metric label="Scheduled backup" value={system.cronConfigured ? "Configured" : "Needs setup"} urgent={!system.cronConfigured} />
        <Metric label="Storage" value={system.backupBucketPrivate ? "Private cloud" : "Check setup"} />
      </div>

      <Panel title="Cloud backup control">
        <div className="backupIntro">
          <div>
            <h3>Operational snapshot</h3>
            <p>Creates a compressed cloud export of admin, listing, user metadata, finance, task and moderation records. Passwords, access tokens, secret keys and document contents are excluded.</p>
          </div>
          <button onClick={() => request("/api/admin/backups", "POST")}>Create backup now</button>
        </div>
        <div className="backupNotice">
          <strong>Two-layer recovery</strong>
          <p>Use these private operational exports together with Supabase database backups or Point-in-Time Recovery. The admin snapshot is not a substitute for a complete PostgreSQL restore.</p>
        </div>
      </Panel>

      <Panel title="Backup history">
        <div className="tableWrap">
          <table>
            <thead><tr><th>Reference</th><th>Status</th><th>Source</th><th>Size</th><th>Records</th><th>Checksum</th><th>Created</th><th>Action</th></tr></thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td><strong>{row.backup_reference}</strong>{row.failure_message ? <span className="subline errorText">{row.failure_message}</span> : null}</td>
                  <td><Status value={row.status} /></td>
                  <td>{row.trigger_source}</td>
                  <td>{formatBytes(row.size_bytes)}</td>
                  <td>{sumCounts(row.table_counts)}</td>
                  <td><code>{row.sha256 ? row.sha256.slice(0, 16) : "—"}</code></td>
                  <td>{dateTime(row.created_at)}</td>
                  <td>{row.status === "completed" ? <button onClick={() => void downloadBackup(row.id)}>Download</button> : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length ? null : <Empty />}
        </div>
      </Panel>
    </>
  );
}

function SecurityTab({ data }: { data: Overview }) {
  const checks = [
    { label: "Privileged Supabase key", state: data.system.secretKeyServerOnly, detail: "Used only by protected server routes." },
    { label: "Private backup bucket", state: data.system.backupBucketPrivate, detail: "No browser access policy is created." },
    { label: "Daily backup schedule", state: data.system.cronConfigured, detail: "Requires CRON_SECRET in Vercel." },
    { label: "Payment webhook signature", state: data.system.paymentWebhookConfigured, detail: "Requires PAYMENT_WEBHOOK_SECRET before provider events are accepted." },
    { label: "MFA enforcement", state: data.system.mfaRequired, detail: "Enable only after owner and team members enroll MFA." },
    { label: "Administrative audit trail", state: data.audit.length >= 0, detail: "Management actions are written to an append-only operational log." },
  ];

  return (
    <>
      <Panel title="Security posture">
        <div className="securityGrid">
          {checks.map((check) => (
            <article key={check.label} className={check.state ? "secure" : "attention"}>
              <span>{check.state ? "Active" : "Attention"}</span>
              <h3>{check.label}</h3>
              <p>{check.detail}</p>
            </article>
          ))}
        </div>
      </Panel>
      <Panel title="Access-control rules">
        <div className="policyList">
          <p><strong>Owner and admin:</strong> full organisation control, team roles, backups and finance.</p>
          <p><strong>Operations and moderators:</strong> website operations, listings, users, reports and tasks.</p>
          <p><strong>Verification:</strong> application review and assigned tasks.</p>
          <p><strong>Finance:</strong> payment ledger, reconciliation, exports and finance audit records.</p>
          <p><strong>Analyst and viewer:</strong> restricted read-only access according to their role.</p>
        </div>
      </Panel>
      <Panel title="Production security checklist">
        <ol className="checklist">
          <li>Keep SUPABASE_SECRET_KEY server-side and never prefix it with NEXT_PUBLIC.</li>
          <li>Use a separate Vercel project and domain for this portal.</li>
          <li>Turn on MFA for the owner before setting REQUIRE_MFA=true.</li>
          <li>Use a long random CRON_SECRET and PAYMENT_WEBHOOK_SECRET.</li>
          <li>Enable Supabase native backups and Point-in-Time Recovery when the business requires a lower recovery point.</li>
          <li>Review team access and audit history regularly.</li>
        </ol>
      </Panel>
    </>
  );
}

function Audit({ rows, team }: { rows: AuditRow[]; team: TeamRow[] }) {
  return (
    <Panel title="Administrative audit trail">
      <div className="tableWrap">
        <table>
          <thead><tr><th>Time</th><th>Team member</th><th>Action</th><th>Entity</th><th>Details</th></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{dateTime(row.created_at)}</td>
                <td>{team.find((member) => member.user_id === row.admin_user_id)?.display_name || team.find((member) => member.user_id === row.admin_user_id)?.email || "System"}</td>
                <td>{row.action.replaceAll("_", " ")}</td>
                <td>{row.entity_type}</td>
                <td><code>{JSON.stringify(row.metadata || {})}</code></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}

function Login(props: {
  email: string;
  password: string;
  setEmail: (value: string) => void;
  setPassword: (value: string) => void;
  signIn: () => void;
  googleSignIn: () => void;
  message: string;
}) {
  return (
    <div className="loginPage">
      <section className="loginCard">
        <div className="brand large"><span className="brandMark">L</span><div><strong>LoadLink Control</strong><small>Restricted organisation system</small></div></div>
        <h1>Private sign in</h1>
        <p>Authorised team members only. Access is controlled by the account, organisation role and private server configuration.</p>
        {props.message ? <div className="error">{props.message}</div> : null}
        <input type="email" placeholder="Work email" value={props.email} onChange={(event) => props.setEmail(event.target.value)} />
        <input type="password" placeholder="Password" value={props.password} onChange={(event) => props.setPassword(event.target.value)} />
        <button className="primary" onClick={props.signIn}>Sign in</button>
        <button className="google" onClick={props.googleSignIn}>Continue with Google</button>
        <small className="security">The publishable key is used only for authentication. Privileged operations use the protected server-side Supabase secret key.</small>
      </section>
    </div>
  );
}

function Metric({ label, value, urgent = false }: { label: string; value: string | number; urgent?: boolean }) {
  return <div className={`metric ${urgent ? "urgent" : ""}`}><small>{label}</small><strong>{value}</strong></div>;
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="panel"><div className="panelHead"><h2>{title}</h2></div>{children}</section>;
}

function QueuePanel({ title, count, children }: { title: string; count: number; children: React.ReactNode }) {
  return <section className="panel queuePanel"><div className="panelHead"><h2>{title}</h2><span className="queueCount">{count}</span></div>{children}</section>;
}

function Status({ value }: { value: string }) {
  return <span className={`status ${value}`}>{value.replaceAll("_", " ")}</span>;
}

function Empty() {
  return <div className="empty">Nothing requires attention here.</div>;
}

function Loading() {
  return <div className="loading"><span /></div>;
}

function date(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-ZA", { day: "numeric", month: "short", year: "numeric" });
}

function dateTime(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-ZA");
}

function money(cents = 0, currency = "ZAR") {
  return new Intl.NumberFormat("en-ZA", { style: "currency", currency }).format(Number(cents || 0) / 100);
}

function relativeDate(value?: string | null) {
  if (!value) return "Not yet";
  const hours = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 3600000));
  if (hours < 1) return "Under 1 hour ago";
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

function formatBytes(value?: number | null) {
  const bytes = Number(value || 0);
  if (!bytes) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function sumCounts(value?: Record<string, number> | null) {
  return Object.values(value || {}).reduce((sum, item) => sum + Number(item || 0), 0).toLocaleString("en-ZA");
}

function queueCount(data: Overview) {
  return (data.metrics.pendingListings || 0)
    + (data.metrics.pendingVerifications || 0)
    + (data.metrics.openReports || 0)
    + (data.metrics.overdueTasks || 0)
    + (data.metrics.disputedPayments || 0);
}
