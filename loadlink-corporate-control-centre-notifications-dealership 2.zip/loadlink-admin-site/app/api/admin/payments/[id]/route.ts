import { errorResponse, notifyUser, requireAdmin, writeAudit } from "@/lib/adminServer";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { user, admin } = await requireAdmin(request, "payments.manage");
    const { id } = await context.params;
    const body = await request.json();
    const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };

    if (body.status !== undefined) {
      const status = String(body.status);
      if (!["pending", "paid", "failed", "refunded", "cancelled"].includes(status)) {
        return Response.json({ error: "Invalid payment status." }, { status: 400 });
      }
      updates.status = status;
      if (status === "paid") updates.settled_at = new Date().toISOString();
      if (status === "refunded") updates.refunded_at = new Date().toISOString();
    }

    if (body.reconciliationStatus !== undefined) {
      const reconciliation = String(body.reconciliationStatus);
      if (!["unmatched", "matched", "reconciled", "disputed"].includes(reconciliation)) {
        return Response.json({ error: "Invalid reconciliation status." }, { status: 400 });
      }
      updates.reconciliation_status = reconciliation;
      if (reconciliation === "reconciled") {
        updates.reconciled_at = new Date().toISOString();
        updates.reconciled_by = user.id;
      } else {
        updates.reconciled_at = null;
        updates.reconciled_by = null;
      }
    }

    for (const [input, column] of [
      ["externalReference", "external_reference"],
      ["providerTransactionId", "provider_transaction_id"],
      ["paymentMethod", "payment_method"],
      ["payerEmail", "payer_email"],
      ["description", "description"],
      ["notes", "notes"],
      ["refundReference", "refund_reference"],
      ["receiptUrl", "receipt_url"],
    ] as const) {
      if (body[input] !== undefined) updates[column] = String(body[input] || "").trim() || null;
    }

    const { data, error } = await admin.from("admin_payments").update(updates).eq("id", id).select("*").single();
    if (error) throw error;

    if (body.status !== undefined && data.user_id) {
      const amount = `${String(data.currency || "ZAR").toUpperCase()} ${(Number(data.amount_cents || 0) / 100).toFixed(2)}`;
      const statusCopy: Record<string, { title: string; message: string }> = {
        pending: { title: "Payment recorded", message: `Your payment ${data.reference} for ${amount} is being processed.` },
        paid: { title: "Payment received", message: `We received ${amount}. Reference: ${data.reference}.` },
        failed: { title: "Payment failed", message: `Payment ${data.reference} was not successful.` },
        refunded: { title: "Payment refunded", message: `Payment ${data.reference} has been refunded.` },
        cancelled: { title: "Payment cancelled", message: `Payment ${data.reference} was cancelled.` },
      };
      const copy = statusCopy[String(data.status)] || statusCopy.pending;
      await notifyUser({
        admin,
        userId: data.user_id,
        type: `payment_${data.status}`,
        title: copy.title,
        message: copy.message,
        entityType: "payment",
        entityId: data.id,
        metadata: { status: data.status, reference: data.reference, amountCents: data.amount_cents, currency: data.currency },
      });
    }

    await writeAudit({
      admin,
      adminUserId: user.id,
      action: "payment_updated",
      entityType: "payment",
      entityId: id,
      metadata: { reference: data.reference, updates },
    });
    return Response.json({ row: data });
  } catch (error) {
    return errorResponse(error);
  }
}
