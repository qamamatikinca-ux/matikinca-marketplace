import { errorResponse, requireAdmin } from "@/lib/adminServer";

const documentFields = [
  ["Identity document", "id_document_path"],
  ["Driver's licence", "licence_document_path"],
  ["Vehicle registration", "registration_document_path"],
  ["Ownership authority", "ownership_document_path"],
  ["Roadworthy certificate", "roadworthy_document_path"],
  ["Operating licence", "operating_licence_document_path"],
  ["Modification paperwork", "modification_document_path"],
  ["CIPC registration", "company_registration_document_path"],
  ["SARS tax document", "tax_document_path"],
  ["Business address proof", "business_address_document_path"],
  ["Representative authority", "representative_authority_document_path"],
] as const;

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { admin } = await requireAdmin(request, "verifications.manage");
    const { id } = await context.params;

    const columns = documentFields.map(([, column]) => column).join(",");
    const { data, error } = await admin.from("vehicle_verifications").select(columns).eq("id", id).single();
    if (error) throw error;

    const documents: Array<{ label: string; url: string }> = [];
    const row = data as unknown as Record<string, unknown>;
    for (const [label, column] of documentFields) {
      const path = row[column];
      if (!path || typeof path !== "string") continue;
      const signed = await admin.storage.from("vehicle-verification").createSignedUrl(path, 300);
      if (!signed.error && signed.data?.signedUrl) documents.push({ label, url: signed.data.signedUrl });
    }

    return Response.json({ documents });
  } catch (error) {
    return errorResponse(error);
  }
}
