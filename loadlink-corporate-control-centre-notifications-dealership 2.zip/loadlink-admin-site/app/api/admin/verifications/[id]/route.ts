import { errorResponse, notifyUser, requireAdmin, writeAudit } from "@/lib/adminServer";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { user, admin } = await requireAdmin(request, "verifications.manage");
    const { id } = await context.params;
    const body = await request.json();
    const status = String(body.status || "");
    const notes = String(body.notes || "").trim();

    if (!["under_review", "more_information_required", "verified", "rejected", "pending"].includes(status)) {
      return Response.json({ error: "Invalid status." }, { status: 400 });
    }
    if (["rejected", "more_information_required"].includes(status) && notes.length < 3) {
      return Response.json({ error: "Add a clear reason for the user." }, { status: 400 });
    }

    const { data, error } = await admin.from("vehicle_verifications").update({
      status,
      reviewer_notes: notes || null,
      reviewed_at: ["verified", "rejected"].includes(status) ? new Date().toISOString() : null,
    }).eq("id", id).select("id,listing_id,user_id,status,dealership_application,dealership_name").single();
    if (error) throw error;

    if (data.listing_id && status === "verified") {
      await admin.from("truck_listing_details").update({ specification_status: "verified" }).eq("listing_id", data.listing_id);
    }

    const copy = status === "verified"
      ? { title: "Verification approved", message: `${data.dealership_application ? `${data.dealership_name || "Your dealership"} and the truck` : "Your truck"} passed verification.` }
      : status === "rejected"
        ? { title: "Verification was not approved", message: `Reason: ${notes}` }
        : status === "more_information_required"
          ? { title: "More information is required", message: notes }
          : status === "under_review"
            ? { title: "Verification under review", message: "Your documents are being reviewed by the LoadLink team." }
            : { title: "Verification received", message: "Your verification application is waiting for review." };

    await notifyUser({
      admin,
      userId: data.user_id,
      type: `verification_${status}`,
      title: copy.title,
      message: copy.message,
      entityType: "vehicle_verification",
      entityId: data.id,
      actionUrl: "/verification-status",
      metadata: { status, reason: notes, listingId: data.listing_id, dealership: Boolean(data.dealership_application) },
    });

    await writeAudit({
      admin,
      adminUserId: user.id,
      action: `verification_${status}`,
      entityType: "vehicle_verification",
      entityId: id,
      metadata: { notes, listingId: data.listing_id },
    });

    return Response.json({ row: data });
  } catch (error) {
    return errorResponse(error);
  }
}
