import { errorResponse, requireAdmin, securityConfiguration } from "@/lib/adminServer";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const { adminUser, admin } = await requireAdmin(request, "dashboard.read");

    const [
      usersResult,
      listingsResult,
      verificationsResult,
      paymentsResult,
      moderationResult,
      teamResult,
      tasksResult,
      reportsResult,
      auditResult,
      backupsResult,
      notificationsResult,
      settingsResult,
    ] = await Promise.all([
      admin.auth.admin.listUsers({ page: 1, perPage: 1000 }),
      admin.from("job_listings").select("id,title,city,posted_by,package_type,status,moderation_status,moderation_notes,created_at,user_id,photos", { count: "exact" }).order("created_at", { ascending: false }).limit(1000),
      admin.from("vehicle_verifications").select("id,listing_id,user_id,status,reviewer_notes,created_at,dealership_application,dealership_name,company_registration_number,tax_number", { count: "exact" }).order("created_at", { ascending: false }).limit(1000),
      admin.from("admin_payments").select("id,user_id,listing_id,amount_cents,currency,status,provider,reference,external_reference,provider_transaction_id,payment_method,payer_email,description,reconciliation_status,reconciled_at,due_at,settled_at,refunded_at,refund_reference,receipt_url,notes,created_at,updated_at", { count: "exact" }).order("created_at", { ascending: false }).limit(1000),
      admin.from("user_moderation_profiles").select("user_id,status,reason,internal_notes,strike_count,suspended_until,last_action_at", { count: "exact" }).limit(1000),
      admin.from("admin_users").select("user_id,email,display_name,role,department,is_active,last_seen_at,created_at").order("created_at", { ascending: true }),
      admin.from("admin_tasks").select("id,title,description,department,priority,status,assigned_to,created_by,entity_type,entity_id,due_at,completed_at,created_at,updated_at").order("created_at", { ascending: false }).limit(1000),
      admin.from("user_reports").select("id,reported_user_id,reporter_user_id,listing_id,category,details,status,assigned_to,resolution_notes,created_at,resolved_at", { count: "exact" }).order("created_at", { ascending: false }).limit(1000),
      admin.from("admin_audit_logs").select("id,admin_user_id,action,entity_type,entity_id,metadata,created_at").order("created_at", { ascending: false }).limit(500),
      admin.from("admin_backup_snapshots").select("id,backup_reference,status,trigger_source,object_path,size_bytes,sha256,table_counts,included_resources,failure_message,triggered_by,started_at,completed_at,expires_at,created_at").order("created_at", { ascending: false }).limit(100),
      admin.from("admin_notifications").select("id,title,body,severity,category,entity_type,entity_id,assigned_to,is_read,created_at").eq("is_read", false).order("created_at", { ascending: false }).limit(100),
      admin.from("admin_settings").select("key,value,updated_at").order("key", { ascending: true }),
    ]);

    for (const result of [
      listingsResult,
      verificationsResult,
      paymentsResult,
      moderationResult,
      teamResult,
      tasksResult,
      reportsResult,
      auditResult,
      backupsResult,
      notificationsResult,
      settingsResult,
    ]) {
      if (result.error && !/does not exist|schema cache/i.test(result.error.message)) throw result.error;
    }

    const authUsers = usersResult.data?.users || [];
    const moderation = new Map((moderationResult.data || []).map((row) => [row.user_id, row]));
    const team = teamResult.data || [];
    const teamMap = new Map(team.map((row) => [row.user_id, row]));
    const listings = listingsResult.data || [];
    const verifications = verificationsResult.data || [];
    const payments = paymentsResult.data || [];
    const tasks = tasksResult.data || [];
    const reports = reportsResult.data || [];
    const backups = backupsResult.data || [];
    const paidCents = payments.filter((item) => item.status === "paid").reduce((sum, item) => sum + Number(item.amount_cents || 0), 0);
    const pendingCents = payments.filter((item) => item.status === "pending").reduce((sum, item) => sum + Number(item.amount_cents || 0), 0);
    const refundedCents = payments.filter((item) => item.status === "refunded").reduce((sum, item) => sum + Number(item.amount_cents || 0), 0);
    const latestBackup = backups.find((item) => item.status === "completed") || null;

    const users = authUsers.map((user) => ({
      id: user.id,
      email: user.email || "",
      createdAt: user.created_at,
      lastSignInAt: user.last_sign_in_at,
      name: String(user.user_metadata?.full_name || user.user_metadata?.name || ""),
      bannedUntil: user.banned_until || null,
      moderation: moderation.get(user.id) || { status: "active", strike_count: 0 },
      team: teamMap.get(user.id) || null,
      listingsCount: listings.filter((item) => item.user_id === user.id).length,
    }));

    return Response.json({
      generatedAt: new Date().toISOString(),
      currentAdmin: adminUser,
      metrics: {
        totalUsers: authUsers.length,
        activeUsers: users.filter((user) => user.moderation.status === "active").length,
        restrictedUsers: users.filter((user) => ["flagged", "suspended", "blocked"].includes(user.moderation.status)).length,
        totalListings: listingsResult.count ?? listings.length,
        pendingListings: listings.filter((item) => item.moderation_status === "pending").length,
        approvedListings: listings.filter((item) => item.moderation_status === "approved").length,
        pendingVerifications: verifications.filter((item) => ["pending", "under_review"].includes(item.status)).length,
        paymentCount: paymentsResult.count ?? payments.length,
        paidCents,
        pendingCents,
        refundedCents,
        unreconciledPayments: payments.filter((item) => item.reconciliation_status !== "reconciled").length,
        disputedPayments: payments.filter((item) => item.reconciliation_status === "disputed").length,
        openTasks: tasks.filter((item) => !["done", "cancelled"].includes(item.status)).length,
        overdueTasks: tasks.filter((item) => item.due_at && new Date(item.due_at) < new Date() && !["done", "cancelled"].includes(item.status)).length,
        openReports: reports.filter((item) => ["open", "reviewing"].includes(item.status)).length,
        teamMembers: team.filter((item) => item.is_active).length,
        unreadNotifications: notificationsResult.data?.length || 0,
        backupCount: backups.filter((item) => item.status === "completed").length,
        failedBackups: backups.filter((item) => item.status === "failed").length,
      },
      users,
      listings,
      verifications,
      payments,
      team,
      tasks,
      reports,
      backups,
      notifications: notificationsResult.data || [],
      settings: settingsResult.data || [],
      audit: auditResult.data || [],
      system: {
        ...securityConfiguration(),
        latestBackupAt: latestBackup?.completed_at || null,
        latestBackupReference: latestBackup?.backup_reference || null,
        backupBucketPrivate: true,
        autoRefreshMinutes: 10,
      },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return errorResponse(error);
  }
}
