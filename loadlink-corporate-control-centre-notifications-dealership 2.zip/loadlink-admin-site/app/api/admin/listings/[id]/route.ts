import { errorResponse, notifyUser, requireAdmin, writeAudit } from "@/lib/adminServer";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { user, admin } = await requireAdmin(request, "listings.manage");
    const { id } = await context.params;
    const body = await request.json();
    const status = String(body.status || "");
    const notes = String(body.notes || "").trim();

    if (!["approved", "rejected", "pending"].includes(status)) {
      return Response.json({ error: "Invalid status." }, { status: 400 });
    }
    if (status !== "approved" && notes.length < 3) {
      return Response.json({ error: "Add a clear reason for the user." }, { status: 400 });
    }

    const { data, error } = await admin.from("job_listings").update({
      moderation_status: status,
      moderation_notes: notes || null,
      moderated_at: status === "pending" ? null : new Date().toISOString(),
      moderated_by: status === "pending" ? null : user.id,
    }).eq("id", id).select("id,title,moderation_status,user_id").single();
    if (error) throw error;

    const copy = status === "approved"
      ? {
          title: "Your post was approved",
          message: `“${data.title || "Your listing"}” is now live on LoadLink.`,
        }
      : status === "rejected"
        ? {
            title: "Your post needs changes",
            message: `“${data.title || "Your listing"}” was not approved. Reason: ${notes}`,
          }
        : {
            title: "Your post is under review",
            message: `“${data.title || "Your listing"}” has been returned to the review queue. ${notes}`.trim(),
          };

    await notifyUser({
      admin,
      userId: data.user_id,
      type: `listing_${status}`,
      title: copy.title,
      message: copy.message,
      entityType: "job_listing",
      entityId: data.id,
      actionUrl: "/my-posts",
      metadata: { status, reason: notes, listingTitle: data.title },
    });

    await writeAudit({
      admin,
      adminUserId: user.id,
      action: `listing_${status}`,
      entityType: "job_listing",
      entityId: id,
      metadata: { notes },
    });

    return Response.json({ row: data });
  } catch (error) {
    return errorResponse(error);
  }
}
