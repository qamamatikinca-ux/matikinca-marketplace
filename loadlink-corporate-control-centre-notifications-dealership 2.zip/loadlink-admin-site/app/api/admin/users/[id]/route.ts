import { errorResponse, notifyUser, requireAdmin, writeAudit } from "@/lib/adminServer";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { user, admin } = await requireAdmin(request, "users.manage");
    const { id } = await context.params;
    const body = await request.json();
    const status = String(body.status || "");
    const reason = String(body.reason || "").trim();
    const notes = String(body.notes || "").trim();
    const suspendDays = Math.max(1, Math.min(365, Number(body.suspendDays || 7)));
    if (!["active","flagged","suspended","blocked"].includes(status)) return Response.json({ error: "Invalid user status." }, { status: 400 });
    if (status !== "active" && reason.length < 3) return Response.json({ error: "Add a clear reason for the user." }, { status: 400 });

    const suspendedUntil = status === "suspended" ? new Date(Date.now() + suspendDays * 86400000).toISOString() : null;
    const { data: current } = await admin.from("user_moderation_profiles").select("strike_count").eq("user_id", id).maybeSingle();
    const strikeCount = status === "active" ? Number(current?.strike_count || 0) : Number(current?.strike_count || 0) + 1;

    const { error } = await admin.from("user_moderation_profiles").upsert({
      user_id: id,
      status,
      reason: reason || null,
      internal_notes: notes || null,
      strike_count: strikeCount,
      suspended_until: suspendedUntil,
      last_action_by: user.id,
      last_action_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }, { onConflict: "user_id" });
    if (error) throw error;

    if (status === "blocked") await admin.auth.admin.updateUserById(id, { ban_duration: "876000h" });
    else if (status === "suspended") await admin.auth.admin.updateUserById(id, { ban_duration: `${suspendDays * 24}h` });
    else await admin.auth.admin.updateUserById(id, { ban_duration: "none" });

    if (body.rejectListings && status !== "active") {
      await admin.from("job_listings").update({ moderation_status: "rejected", moderation_notes: `Account ${status}: ${reason || "Admin action"}`, moderated_at: new Date().toISOString(), moderated_by: user.id }).eq("user_id", id);
    }

    const userMessage = status === "active"
      ? "Your LoadLink account access has been restored."
      : status === "flagged"
        ? `Your account received a warning. Reason: ${reason}`
        : status === "suspended"
          ? `Your account has been suspended for ${suspendDays} day${suspendDays === 1 ? "" : "s"}. Reason: ${reason}`
          : `Your account has been blocked. Reason: ${reason}`;

    await notifyUser({
      admin,
      userId: id,
      type: `account_${status}`,
      title: status === "active" ? "Account restored" : status === "flagged" ? "Account warning" : status === "suspended" ? "Account suspended" : "Account blocked",
      message: userMessage,
      entityType: "user_account",
      entityId: id,
      actionUrl: status === "active" || status === "flagged" ? "/" : null,
      metadata: { status, reason, suspendedUntil },
    });

    await writeAudit({ admin, adminUserId: user.id, action: `user_${status}`, entityType: "user", entityId: id, metadata: { reason, notes, suspendDays, rejectListings: Boolean(body.rejectListings) } });
    return Response.json({ ok: true });
  } catch (error) {
    return errorResponse(error);
  }
}
