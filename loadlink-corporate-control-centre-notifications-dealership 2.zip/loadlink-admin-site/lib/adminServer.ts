import { createClient } from "@supabase/supabase-js";

export type AdminRole = "owner" | "admin" | "operations" | "moderator" | "verification" | "finance" | "support" | "analyst" | "viewer";

const rolePermissions: Record<AdminRole, string[]> = {
  owner: ["*"],
  admin: [
    "dashboard.read",
    "listings.manage",
    "verifications.manage",
    "users.manage",
    "reports.manage",
    "team.manage",
    "tasks.manage",
    "payments.manage",
    "payments.export",
    "backups.manage",
    "security.read",
    "settings.manage",
    "audit.read",
  ],
  operations: ["dashboard.read", "listings.manage", "users.review", "reports.manage", "tasks.manage", "audit.read"],
  moderator: ["dashboard.read", "listings.manage", "users.manage", "reports.manage", "tasks.manage"],
  verification: ["dashboard.read", "verifications.manage", "users.review", "tasks.manage"],
  finance: ["dashboard.read", "payments.manage", "payments.export", "tasks.manage", "audit.read"],
  support: ["dashboard.read", "users.review", "reports.manage", "tasks.manage"],
  analyst: ["dashboard.read", "payments.export", "security.read", "audit.read"],
  viewer: ["dashboard.read"],
};

function env() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL || "";
  const publishable = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_PUBLISHABLE_KEY || "";
  const secret = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || "";
  const adminEmail = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  if (!url.startsWith("https://") || publishable.length < 20 || secret.length < 20 || !adminEmail) {
    throw new Error("Admin environment variables are incomplete.");
  }
  return { url, publishable, secret, adminEmail };
}

function jwtPayload(token: string) {
  try {
    const encoded = token.split(".")[1] || "";
    return JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export function adminClient() {
  const { url, secret } = env();
  return createClient(url, secret, { auth: { persistSession: false, autoRefreshToken: false } });
}

export function hasPermission(role: AdminRole, permission: string) {
  const permissions = rolePermissions[role] || [];
  return permissions.includes("*") || permissions.includes(permission);
}

export async function requireAdmin(request: Request, permission = "dashboard.read") {
  const { url, publishable, adminEmail } = env();
  const token = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") || "";
  if (!token) throw new Error("UNAUTHENTICATED");

  const authClient = createClient(url, publishable, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await authClient.auth.getUser(token);
  const user = data.user;
  if (error || !user?.email) throw new Error("UNAUTHENTICATED");

  if (process.env.REQUIRE_MFA === "true" && jwtPayload(token).aal !== "aal2") {
    throw new Error("MFA_REQUIRED");
  }

  const admin = adminClient();
  const email = user.email.toLowerCase();
  const { data: row, error: rowError } = await admin
    .from("admin_users")
    .select("user_id,email,display_name,role,department,is_active")
    .eq("user_id", user.id)
    .maybeSingle();
  if (rowError) throw rowError;

  const role = String(row?.role || "viewer") as AdminRole;
  const allowedOwner = email === adminEmail && row?.is_active === true;
  const allowedTeam = row?.is_active === true && row?.email?.toLowerCase() === email;
  if (!allowedOwner && !allowedTeam) throw new Error("FORBIDDEN");
  if (!hasPermission(role, permission)) throw new Error("FORBIDDEN");

  await admin.from("admin_users").update({ last_seen_at: new Date().toISOString() }).eq("user_id", user.id);
  return { user, admin, adminUser: { ...row, role } };
}

export async function writeAudit(args: {
  admin: ReturnType<typeof adminClient>;
  adminUserId: string;
  action: string;
  entityType: string;
  entityId?: string | null;
  metadata?: Record<string, unknown>;
}) {
  await args.admin.from("admin_audit_logs").insert({
    admin_user_id: args.adminUserId,
    action: args.action,
    entity_type: args.entityType,
    entity_id: args.entityId || null,
    metadata: args.metadata || {},
  });
}


export async function notifyUser(args: {
  admin: ReturnType<typeof adminClient>;
  userId?: string | null;
  type: string;
  title: string;
  message: string;
  entityType?: string | null;
  entityId?: string | null;
  actionUrl?: string | null;
  metadata?: Record<string, unknown>;
}) {
  if (!args.userId) return;
  const { error } = await args.admin.from("user_notifications").insert({
    user_id: args.userId,
    type: args.type,
    title: args.title,
    message: args.message,
    entity_type: args.entityType || null,
    entity_id: args.entityId || null,
    action_url: args.actionUrl || null,
    metadata: args.metadata || {},
  });
  if (error) throw error;
}

export function securityConfiguration() {
  return {
    mfaRequired: process.env.REQUIRE_MFA === "true",
    cronConfigured: Boolean(process.env.CRON_SECRET && process.env.CRON_SECRET.length >= 16),
    paymentWebhookConfigured: Boolean(process.env.PAYMENT_WEBHOOK_SECRET && process.env.PAYMENT_WEBHOOK_SECRET.length >= 24),
    backupRetentionDays: Number(process.env.BACKUP_RETENTION_DAYS || 30),
    secretKeyServerOnly: Boolean(process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY),
  };
}

export function errorResponse(error: unknown) {
  const message = error instanceof Error ? error.message : "Unknown error";
  const status = message === "UNAUTHENTICATED" ? 401 : ["FORBIDDEN", "MFA_REQUIRED"].includes(message) ? 403 : 500;
  const publicMessage = message === "MFA_REQUIRED"
    ? "Multi-factor authentication is required for this admin portal."
    : status === 500 ? message : "Access denied.";
  return Response.json({ error: publicMessage }, { status });
}
