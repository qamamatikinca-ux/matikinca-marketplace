#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_REPO="qamamatikinca-ux/matikinca-marketplace"
TARGET_FILE="components/MarketplaceDiscovery.tsx"
COMMIT_MESSAGE="fix: restore direct LoadLink portal navigation"
STAMP="$(date +%Y%m%d-%H%M%S)"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="${SCRIPT_DIR}/${TARGET_FILE}"
TMP_DIR="$(mktemp -d)"
BACKUP="${TMP_DIR}/MarketplaceDiscovery.tsx.before"
STASH_CREATED=0
SUCCESS=0

say() { printf '\n\033[1;36m%s\033[0m\n' "$*"; }
ok()  { printf '\033[1;32m✓ %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

cleanup() {
  code=$?
  if [[ $code -ne 0 && -f "$BACKUP" && -n "${ROOT:-}" ]]; then
    cp "$BACKUP" "$ROOT/$TARGET_FILE" 2>/dev/null || true
    printf '\nUpdate stopped before push. The project file was restored to its pre-run state.\n' >&2
  fi
  rm -rf "$TMP_DIR"
  exit "$code"
}
trap cleanup EXIT

# Find the repository from the current Codespace directory first, then from the bundle location.
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$ROOT" ]]; then
  probe="$SCRIPT_DIR"
  while [[ "$probe" != "/" ]]; do
    if [[ -d "$probe/.git" ]]; then
      ROOT="$probe"
      break
    fi
    probe="$(dirname "$probe")"
  done
fi
[[ -n "$ROOT" ]] || die "Run this from inside the LoadLink Codespace/repository."
cd "$ROOT"

[[ -f package.json ]] || die "package.json was not found at $ROOT."
[[ -f package-lock.json ]] || die "package-lock.json is missing. This update expects the committed npm lockfile."
[[ -f "$PAYLOAD" ]] || die "Update payload is missing: $PAYLOAD"
mkdir -p "$(dirname "$TARGET_FILE")"
if [[ -f "$TARGET_FILE" ]]; then
  cp "$TARGET_FILE" "$BACKUP"
else
  : > "$BACKUP"
fi

REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
[[ "$REMOTE_URL" == *"$EXPECTED_REPO"* ]] || die "This is not the expected LoadLink repo. origin=$REMOTE_URL"

say "1/6  Protecting local work"
if ! git diff --quiet || ! git diff --cached --quiet; then
  git stash push -m "loadlink-auto-backup-$STAMP" >/dev/null
  STASH_CREATED=1
  ok "Tracked local changes saved in git stash."
else
  ok "No tracked local changes needed stashing."
fi

say "2/6  Syncing main with GitHub"
git fetch origin main
if git show-ref --verify --quiet refs/heads/main; then
  git switch main
else
  git switch -c main --track origin/main
fi
git pull --rebase origin main
ok "main is synced."

say "3/6  Installing the exact update file"
cp "$PAYLOAD" "$TARGET_FILE"

# Verify the four direct routes are present before building.
grep -Fq 'job: "/jobs"' "$TARGET_FILE" || die "Jobs route verification failed."
grep -Fq 'contract: "/contracts"' "$TARGET_FILE" || die "Contracts route verification failed."
grep -Fq 'asset: "/list-your-vehicle"' "$TARGET_FILE" || die "Vehicle route verification failed."
grep -Fq 'driver: "/driver-portal"' "$TARGET_FILE" || die "Driver route verification failed."
ok "Portal route update verified."

say "4/6  Installing dependencies from package-lock.json"
npm ci
ok "Dependencies installed."

say "5/6  Building LoadLink"
npm run build
ok "Next.js production build passed."

say "6/6  Committing and pushing main"
git add "$TARGET_FILE"

if git diff --cached --quiet; then
  ok "GitHub main already contains this exact update; no duplicate commit created."
else
  git commit -m "$COMMIT_MESSAGE"
  ok "Source commit created."
fi

git push origin main

LOCAL_SHA="$(git rev-parse HEAD)"
REMOTE_SHA="$(git ls-remote origin refs/heads/main | awk '{print $1}')"
[[ -n "$REMOTE_SHA" && "$LOCAL_SHA" == "$REMOTE_SHA" ]] || die "Push verification failed: local $LOCAL_SHA, remote $REMOTE_SHA"
ok "GitHub main verified at $LOCAL_SHA"

SUCCESS=1
trap - EXIT
rm -rf "$TMP_DIR"

printf '\n\033[1;32mLOADLINK UPDATE COMPLETE\033[0m\n'
printf 'Branch: main\n'
printf 'Commit: %s\n' "$LOCAL_SHA"
printf 'File:   %s\n' "$TARGET_FILE"

if [[ $STASH_CREATED -eq 1 ]]; then
  printf '\nYour previous tracked local changes were preserved in git stash.\n'
  printf 'Review them with: git stash list\n'
  printf 'Restore them later with: git stash pop\n'
fi
