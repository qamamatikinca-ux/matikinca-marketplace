LOADLINK UPDATE — commit 719283b324aea2358e41121f63e47ef737ef3e46

WHAT IS IN THIS PACKAGE
- components/MarketplaceDiscovery.tsx
  Exact updated LoadLink marketplace discovery component.
- APPLY_LOADLINK_UPDATE.sh
  Safe Codespaces installer/build/commit/push script.
- LOADLINK_UPDATE.patch
  Human-readable Git patch showing only the source change.
- TERMINAL_COMMAND.txt
  The exact commands to run.

WHAT THIS UPDATE DOES
- Jobs category opens /jobs when there are no typed search terms.
- Contracts category opens /contracts.
- Vehicles category opens /list-your-vehicle.
- Drivers category opens /driver-portal.
- If a search term or location is entered, existing scoped search behavior remains active.

IMPORTANT
The script never force-pushes and never hard-resets the repository.
If tracked local edits exist, it saves them to a git stash before syncing main.
It runs npm ci from package-lock.json and npm run build before pushing.
If main already has the exact source update, it does not create a duplicate commit.
