#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$ROOT" ]; then
  echo "ERROR: Run this from inside the LoadLink Codespace repository."
  exit 1
fi

cd "$ROOT"

if [[ "$(git remote get-url origin 2>/dev/null || true)" != *"qamamatikinca-ux/matikinca-marketplace"* ]]; then
  echo "ERROR: This is not the LoadLink repository."
  exit 1
fi

BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WORKFLOW_SOURCE="$BUNDLE_DIR/.github/workflows/loadlink-manual-zip-update-deploy.yml"
ZIP_SOURCE="$BUNDLE_DIR/LoadLink-update-719283b.zip"

test -f "$WORKFLOW_SOURCE" || { echo "ERROR: workflow file missing from installer bundle."; exit 1; }
test -f "$ZIP_SOURCE" || { echo "ERROR: LoadLink update ZIP missing from installer bundle."; exit 1; }

mkdir -p .github/workflows
cp "$WORKFLOW_SOURCE" .github/workflows/loadlink-manual-zip-update-deploy.yml
cp "$ZIP_SOURCE" ./LoadLink-update-719283b.zip

git add .github/workflows/loadlink-manual-zip-update-deploy.yml LoadLink-update-719283b.zip

if git diff --cached --quiet; then
  echo "Workflow and update ZIP are already installed."
else
  git config user.name "${GIT_AUTHOR_NAME:-LoadLink}"
  git config user.email "${GIT_AUTHOR_EMAIL:-loadlink@users.noreply.github.com}"
  git commit -m "chore: add manual LoadLink ZIP deployment workflow"
  git push origin HEAD:main
fi

echo
echo "Installed successfully."
echo "Next: GitHub -> Actions -> LoadLink Manual ZIP Update + Deploy -> Run workflow"
echo "Keep archive_path as: LoadLink-update-719283b.zip"
echo "Keep force_deploy as: true"
