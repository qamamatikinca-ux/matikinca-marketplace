LOADLINK MANUAL WORKFLOW INSTALLER

Files:
1. .github/workflows/loadlink-manual-zip-update-deploy.yml
2. LoadLink-update-719283b.zip
3. INSTALL_WORKFLOW_IN_CODESPACE.sh

Approved update component SHA256:
018541cf6b41f66a354eae7056c8c882c1f48ec3866a1b6031e986506337c4b6

Update ZIP SHA256:
5d9e74d0890d07152f709489a501b76c08fb7bfaaded307013949c1a55607ca1

HOW TO USE
Option A — Codespaces:
- Upload/extract this installer bundle into your LoadLink repository.
- Run:
  chmod +x LoadLink-workflow-installer/INSTALL_WORKFLOW_IN_CODESPACE.sh
  bash LoadLink-workflow-installer/INSTALL_WORKFLOW_IN_CODESPACE.sh
- Then open GitHub -> Actions -> "LoadLink Manual ZIP Update + Deploy" -> Run workflow.
- archive_path: LoadLink-update-719283b.zip
- force_deploy: true

Option B — GitHub web:
- Upload LoadLink-update-719283b.zip to the repository root.
- Upload loadlink-manual-zip-update-deploy.yml to .github/workflows/
- Commit both to main.
- Open Actions and manually run the workflow.

WHAT THE WORKFLOW DOES
- Checks it is running in qamamatikinca-ux/matikinca-marketplace.
- Tests ZIP integrity.
- Extracts the exact MarketplaceDiscovery.tsx.
- Rejects the run if its SHA256 differs from the approved file.
- Checks Jobs, Contracts, Vehicles and Drivers direct portal routes.
- Uses Node 20 and npm ci from package-lock.json.
- Runs npm run build.
- Pushes only after the production build passes.
- If the source already matches and force_deploy=true, creates an empty deployment commit.
- Verifies origin/main matches the validated commit.
- Relies on the existing Vercel Git integration; it does not need VERCEL_TOKEN.

IMPORTANT
No workflow can override an external Vercel rate-limit/quota. If Vercel rejects the Git-triggered deployment,
the GitHub workflow can still complete correctly but Vercel must accept a later deployment.
