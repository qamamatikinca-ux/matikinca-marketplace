"use client";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import AuthStatusButton from "@/components/AuthStatusButton";
import BusinessPlans, { type BusinessPlanId } from "@/components/BusinessPlans";
import HomeLogoLink from "@/components/HomeLogoLink";
import SiteMenu from "@/components/SiteMenu";
import LoadLinkLoading from "@/components/LoadLinkLoading";
import LoadLinkThemeToggle from "@/components/LoadLinkThemeToggle";
import SubmissionSuccess from "@/components/SubmissionSuccess";
import { recordUserActivity, syncAccountState } from "@/lib/accountState";
import { currentRelativePath, isAuthenticatedUser, loginHref } from "@/lib/auth";
import { getAccountOwnerKey, getOwnedJobKeys, setOwnedJobKeys } from "@/lib/chatKeys";
import { formatListingRate } from "@/lib/formatCurrency";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";
import { useLoadLinkTheme } from "@/lib/useLoadLinkTheme";
import { getTruckModel, getTruckModels, truckCatalog, truckYears, validateTruckTransmission } from "@/lib/truckCatalog";

const cityOptions = [
  "Johannesburg", "Sandton", "Midrand", "Pretoria", "Centurion", "Soweto", "Kempton Park", "Boksburg",
  "Benoni", "Germiston", "Alberton", "Randburg", "Roodepoort", "Krugersdorp", "Vereeniging", "Vanderbijlpark",
  "Durban", "Pinetown", "Umhlanga", "Pietermaritzburg", "Richards Bay", "Cape Town", "Bellville", "Stellenbosch",
  "Paarl", "George", "Gqeberha", "East London", "Mthatha", "Bloemfontein", "Welkom", "Kimberley", "Upington",
  "Rustenburg", "Klerksdorp", "Polokwane", "Mbombela", "Emalahleni", "Middelburg", "Secunda", "Other",
];

const truckBodyTypes = [
  "Tractor unit / horse", "Side tipper", "Dropside", "Flat deck", "Tautliner", "Refrigerated body", "Closed box body",
  "Lowbed", "Mixer", "Tipper", "Tanker", "Curtainsider", "Car carrier", "Refuse truck", "Tow truck", "Fire truck",
  "Crane truck", "Logging truck", "Other",
];
const trailerTypes = ["Flatbed", "Tautliner", "Side Tipper", "End Tipper", "Refrigerated", "Tanker", "Lowbed", "Livestock", "Car Carrier", "Container", "Other"];
const mobileUnitTypes = ["Mobile Toilet", "Food Truck", "Mobile Kitchen", "Mobile Clinic", "Mobile Office", "Mobile Workshop", "Mobile Classroom", "Mobile Accommodation", "Mobile Shower", "Cold Room", "Other"];
const gearboxOptions = ["Manual", "Automatic", "Automated manual", "Electric direct drive", "Not applicable", "Converted / custom"];
const acceptedDocuments = ".jpg,.jpeg,.png,.webp,.pdf";

type VehicleCategory = "truck" | "trailer" | "mobile_unit";
type SellerType = "private" | "dealership";
type VerificationFiles = {
  idDocument: File | null;
  driverLicence: File | null;
  registrationPaper: File | null;
  ownershipProof: File | null;
  roadworthy: File | null;
  operatingLicence: File | null;
  modificationProof: File | null;
  companyRegistration: File | null;
  taxDocument: File | null;
  businessAddress: File | null;
  representativeAuthority: File | null;
};
type ReferenceImage = { imageUrl: string; title: string; exactMatch: boolean; sourceUrl?: string };

const emptyVerificationFiles: VerificationFiles = {
  idDocument: null, driverLicence: null, registrationPaper: null, ownershipProof: null,
  roadworthy: null, operatingLicence: null, modificationProof: null,
  companyRegistration: null, taxDocument: null, businessAddress: null, representativeAuthority: null,
};

function normalizePhone(value: string) { return value.replace(/[^\d+]/g, ""); }
function isValidSouthAfricanPhone(value: string) { const clean = normalizePhone(value); return /^0\d{9}$/.test(clean) || /^\+27\d{9}$/.test(clean); }
function safeFileName(value: string) { return value.toLowerCase().replace(/[^a-z0-9.]+/g, "-").replace(/^-+|-+$/g, "") || "document"; }
function categoryLabel(category: VehicleCategory) { return category === "truck" ? "Truck" : category === "trailer" ? "Trailer" : "Mobile Unit"; }

function resizePhoto(file: File, maxWidth = 1600, quality = 0.82): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, maxWidth / image.width);
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext("2d");
        if (!context) return reject(new Error("Could not process the vehicle image."));
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Could not prepare the vehicle image.")), "image/jpeg", quality);
      };
      image.onerror = () => reject(new Error("Could not read the vehicle image."));
      image.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error("Could not read the vehicle image."));
    reader.readAsDataURL(file);
  });
}

export default function ListYourVehiclePage() {
  const router = useRouter();
  const { darkMode, toggleTheme } = useLoadLinkTheme();
  const [authReady, setAuthReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  const [sellerType, setSellerType] = useState<SellerType>("private");
  const [vehicleCategory, setVehicleCategory] = useState<VehicleCategory | null>(null);
  const [vehicleSubtype, setVehicleSubtype] = useState("");
  const [dealershipId, setDealershipId] = useState("");
  const [dealershipName, setDealershipName] = useState("");
  const [dealerPost, setDealerPost] = useState(false);

  const [year, setYear] = useState(2026);
  const [brand, setBrand] = useState("");
  const [modelName, setModelName] = useState("");
  const [modelConfirmed, setModelConfirmed] = useState(false);
  const [referenceImage, setReferenceImage] = useState<ReferenceImage | null>(null);
  const [imageLoading, setImageLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [city, setCity] = useState("Johannesburg");
  const [bodyType, setBodyType] = useState("");
  const [transmission, setTransmission] = useState("");
  const [fuelType, setFuelType] = useState("");
  const [axleConfiguration, setAxleConfiguration] = useState("");
  const [registrationNumber, setRegistrationNumber] = useState("");
  const [vin, setVin] = useState("");
  const [engineNumber, setEngineNumber] = useState("");
  const [odometerKm, setOdometerKm] = useState("");
  const [previousOwners, setPreviousOwners] = useState("");
  const [condition, setCondition] = useState("Good");
  const [serviceHistory, setServiceHistory] = useState("Partial service history");
  const [gvmKg, setGvmKg] = useState("");
  const [payloadKg, setPayloadKg] = useState("");
  const [rate, setRate] = useState("");
  const [postedBy, setPostedBy] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [description, setDescription] = useState("");
  const [packageType, setPackageType] = useState<"standard" | "pro" | "dealer">("standard");
  const [selectedPlan, setSelectedPlan] = useState<BusinessPlanId | null>(null);
  const [vehiclePhotos, setVehiclePhotos] = useState<File[]>([]);
  const [vehiclePreviews, setVehiclePreviews] = useState<string[]>([]);
  const [documents, setDocuments] = useState<VerificationFiles>(emptyVerificationFiles);
  const [confirmOwnership, setConfirmOwnership] = useState(false);
  const [confirmAccuracy, setConfirmAccuracy] = useState(false);
  const [companyRegistrationNumber, setCompanyRegistrationNumber] = useState("");
  const [taxNumber, setTaxNumber] = useState("");

  const availableModels = useMemo(() => vehicleCategory === "truck" ? getTruckModels(brand, year) : [], [brand, vehicleCategory, year]);
  const selectedModel = useMemo(() => vehicleCategory === "truck" ? getTruckModel(brand, modelName, year) : null, [brand, modelName, vehicleCategory, year]);
  const transmissionCheck = useMemo(() => vehicleCategory === "truck" && transmission ? validateTruckTransmission(brand, modelName, year, transmission) : null, [brand, modelName, transmission, vehicleCategory, year]);

  useEffect(() => {
    async function requireAccount() {
      if (!isSupabaseConfigured) { router.replace(loginHref(currentRelativePath())); return; }
      const { data: { user } } = await supabase.auth.getUser();
      if (!isAuthenticatedUser(user)) { router.replace(loginHref(currentRelativePath())); return; }
      await syncAccountState().catch(() => undefined);
      setPostedBy(String(user.user_metadata?.full_name || user.user_metadata?.name || ""));

      const params = new URLSearchParams(window.location.search);
      const requestedPlan = params.get("plan");
      if (requestedPlan === "manual" || requestedPlan === "pro" || requestedPlan === "dealer") {
        setSelectedPlan(requestedPlan);
        setPackageType(requestedPlan === "manual" ? "standard" : requestedPlan);
      }
      const requestedDealer = params.get("dealership") || "";
      if (requestedDealer) {
        const { data } = await supabase.from("dealership_profiles").select("id,name,contact_email,phone_number,whatsapp_number").eq("id", requestedDealer).eq("owner_user_id", user.id).maybeSingle();
        if (data) {
          setDealershipId(String(data.id));
          setDealershipName(String(data.name || ""));
          setPostedBy(String(data.name || postedBy));
          setContactNumber(String(data.phone_number || ""));
          setWhatsappNumber(String(data.whatsapp_number || ""));
          setSellerType("dealership");
          setDealerPost(true);
          setSelectedPlan("dealer");
          setPackageType("dealer");
        }
      }
      setAuthReady(true);
    }
    void requireAccount().catch(() => router.replace(loginHref(currentRelativePath())));
  }, [router]);

  useEffect(() => {
    if (vehicleCategory !== "truck" || !brand || !modelName) return;
    let active = true;
    setImageLoading(true);
    fetch(`/api/truck-image?brand=${encodeURIComponent(brand)}&model=${encodeURIComponent(modelName)}&year=${year}`, { cache: "force-cache" })
      .then((response) => response.json()).then((data) => { if (active) setReferenceImage(data); })
      .catch(() => { if (active) setReferenceImage(null); }).finally(() => { if (active) setImageLoading(false); });
    return () => { active = false; };
  }, [brand, modelName, vehicleCategory, year]);

  function choosePlan(plan: BusinessPlanId) {
    setSelectedPlan(plan);
    setPackageType(plan === "manual" ? "standard" : plan);
    if (plan === "dealer") setSellerType("dealership");
    setMessage("");
    requestAnimationFrame(() => document.getElementById("vehicle-type")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  }

  function chooseCategory(category: VehicleCategory) {
    setVehicleCategory(category);
    setVehicleSubtype("");
    setBodyType(category === "truck" ? "Tractor unit / horse" : "");
    setBrand(""); setModelName(""); setModelConfirmed(false); setReferenceImage(null);
    setTransmission(category === "trailer" ? "Not applicable" : "");
    setFuelType(category === "trailer" ? "Not applicable" : "");
    setAxleConfiguration(""); setTitle(""); setMessage("");
  }

  function confirmSelectedModel() {
    if (!selectedModel) { setMessage("Choose a valid year, truck brand and model first."); return; }
    setTitle(`${year} ${brand} ${modelName}`);
    setTransmission(selectedModel.transmissions[0] || "");
    setFuelType(selectedModel.fuels[0] || "Diesel");
    setAxleConfiguration(selectedModel.axleConfigurations[0] || "4x2");
    setModelConfirmed(true);
    setMessage("");
  }

  async function handleVehiclePhotos(event: ChangeEvent<HTMLInputElement>) {
    const max = packageType === "pro" || packageType === "dealer" ? 15 : 8;
    const selected = Array.from(event.target.files ?? []).slice(0, max) as File[];
    setVehiclePhotos(selected);
    const previews = await Promise.all(selected.map((file) => new Promise<string>((resolve, reject) => {
      const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file);
    })));
    setVehiclePreviews(previews);
  }

  function setDocument(key: keyof VerificationFiles, file: File | null) { setDocuments((current) => ({ ...current, [key]: file })); }
  async function uploadVehiclePhoto(file: File, userId: string) {
    const resized = await resizePhoto(file);
    const path = `vehicles/${userId}/${Date.now()}-${Math.random().toString(36).slice(2)}-${safeFileName(file.name)}.jpg`;
    const result = await supabase.storage.from("job-photos").upload(path, resized, { cacheControl: "3600", contentType: "image/jpeg", upsert: false });
    if (result.error) throw result.error;
    return supabase.storage.from("job-photos").getPublicUrl(path).data.publicUrl;
  }
  async function uploadVerificationDocument(file: File, userId: string, folder: string, label: string) {
    if (file.size > 10 * 1024 * 1024) throw new Error(`${label} must be smaller than 10 MB.`);
    const path = `${userId}/${folder}/${Date.now()}-${safeFileName(file.name)}`;
    const result = await supabase.storage.from("vehicle-verification").upload(path, file, { cacheControl: "3600", contentType: file.type || undefined, upsert: false });
    if (result.error) throw result.error;
    return path;
  }

  function validateBeforeSubmit() {
    if (!vehicleCategory) return "Choose whether you are listing a truck, trailer or mobile unit.";
    if (vehicleCategory === "truck") {
      if (!modelConfirmed || !selectedModel) return "Confirm the exact truck model before continuing.";
      if (!transmissionCheck?.valid) return transmissionCheck?.message || "Choose a valid gearbox.";
    } else {
      if (!vehicleSubtype) return `Choose the ${vehicleCategory === "trailer" ? "trailer" : "mobile unit"} type.`;
      if (!brand.trim() || !modelName.trim()) return "Enter the make and model.";
    }
    if (!title.trim() || !postedBy.trim() || !rate.trim() || !description.trim()) return "Complete all required vehicle and listing fields.";
    if (!registrationNumber.trim() || vin.trim().length < 6) return "Enter the registration number and VIN/chassis number.";
    if (!odometerKm || Number(odometerKm) < 0) return "Enter a valid mileage or usage reading.";
    if (!isValidSouthAfricanPhone(contactNumber)) return "Enter a valid South African contact number.";
    if (whatsappNumber && !isValidSouthAfricanPhone(whatsappNumber)) return "Enter a valid WhatsApp number or leave it blank.";
    if (vehiclePhotos.length < 2) return "Upload at least two clear photos of the actual vehicle or unit.";
    if (!documents.idDocument || !documents.registrationPaper || !documents.ownershipProof) return "Upload your ID, registration paper and proof of ownership or authority to list.";
    if (vehicleCategory === "truck" && !documents.driverLicence) return "Upload the driver’s licence for the truck listing.";
    if (transmissionCheck?.requiresModificationProof && !documents.modificationProof) return "Upload gearbox conversion or engineering paperwork.";
    if (sellerType === "dealership" && !dealerPost) {
      if (!dealershipName.trim() || !companyRegistrationNumber.trim() || !taxNumber.trim()) return "Enter the dealership and registration information.";
      if (!documents.companyRegistration || !documents.taxDocument || !documents.businessAddress || !documents.representativeAuthority) return "Upload the dealership verification documents.";
    }
    if (!confirmOwnership || !confirmAccuracy) return "Confirm ownership authority and the accuracy of the information.";
    return "";
  }

  async function submitVehicle(event: FormEvent) {
    event.preventDefault();
    setMessage("");
    const validationMessage = validateBeforeSubmit();
    if (validationMessage) { setMessage(validationMessage); return; }
    setSaving(true);
    let createdListingId = "";
    let createdOwnerKey = "";
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!isAuthenticatedUser(user)) { router.replace(loginHref(currentRelativePath())); return; }
      const ownerKey = getAccountOwnerKey(user.id); createdOwnerKey = ownerKey;
      const folder = crypto.randomUUID();
      const photoUrls: string[] = [];
      for (const file of vehiclePhotos) photoUrls.push(await uploadVehiclePhoto(file, user.id));

      const idPath = await uploadVerificationDocument(documents.idDocument!, user.id, folder, "ID document");
      const licencePath = documents.driverLicence ? await uploadVerificationDocument(documents.driverLicence, user.id, folder, "Driver's licence") : null;
      const registrationPath = await uploadVerificationDocument(documents.registrationPaper!, user.id, folder, "Vehicle registration paper");
      const ownershipPath = await uploadVerificationDocument(documents.ownershipProof!, user.id, folder, "Proof of ownership");
      const roadworthyPath = documents.roadworthy ? await uploadVerificationDocument(documents.roadworthy, user.id, folder, "Roadworthy certificate") : null;
      const operatingLicencePath = documents.operatingLicence ? await uploadVerificationDocument(documents.operatingLicence, user.id, folder, "Operating licence") : null;
      const modificationProofPath = documents.modificationProof ? await uploadVerificationDocument(documents.modificationProof, user.id, folder, "Modification paperwork") : null;
      const companyRegistrationPath = sellerType === "dealership" && !dealerPost && documents.companyRegistration ? await uploadVerificationDocument(documents.companyRegistration, user.id, folder, "Company registration") : null;
      const taxDocumentPath = sellerType === "dealership" && !dealerPost && documents.taxDocument ? await uploadVerificationDocument(documents.taxDocument, user.id, folder, "Tax document") : null;
      const businessAddressPath = sellerType === "dealership" && !dealerPost && documents.businessAddress ? await uploadVerificationDocument(documents.businessAddress, user.id, folder, "Business address proof") : null;
      const representativeAuthorityPath = sellerType === "dealership" && !dealerPost && documents.representativeAuthority ? await uploadVerificationDocument(documents.representativeAuthority, user.id, folder, "Representative authority") : null;

      const label = categoryLabel(vehicleCategory!);
      const subtype = vehicleCategory === "truck" ? bodyType : vehicleSubtype;
      const storedDescription = [
        `Listing type: ${label}`,
        `Vehicle subtype: ${subtype}`,
        `Year: ${year}`,
        `Make: ${brand.trim()}`,
        `Model: ${modelName.trim()}`,
        `Mileage: ${Number(odometerKm).toLocaleString("en-ZA")} km`,
        previousOwners ? `Previous owners: ${previousOwners}` : "",
        transmission ? `Transmission: ${transmission}` : "",
        fuelType ? `Fuel: ${fuelType}` : "",
        axleConfiguration ? `Axle configuration: ${axleConfiguration}` : "",
        `Condition: ${condition}`,
        `Service history: ${serviceHistory}`,
        gvmKg ? `GVM: ${Number(gvmKg).toLocaleString("en-ZA")} kg` : "",
        payloadKg ? `Payload: ${Number(payloadKg).toLocaleString("en-ZA")} kg` : "",
        `Seller: ${sellerType === "dealership" ? dealershipName || postedBy : postedBy}`,
        "",
        "Description:",
        description.trim(),
      ].filter(Boolean).join("\n");

      const listingResult = await supabase.from("job_listings").insert({
        title: title.trim(), city,
        vehicle_group: vehicleCategory === "mobile_unit" ? "Mobile Units" : "Trucks / Trailers",
        rate: formatListingRate(rate), posted_by: postedBy.trim(), contact_number: contactNumber.trim(), whatsapp_number: whatsappNumber.trim(),
        description: storedDescription, photos: photoUrls,
        sponsored: packageType === "pro" || packageType === "dealer", package_type: packageType,
        listing_kind: "vehicle", display_tier: packageType === "dealer" ? 4 : packageType === "pro" ? 3 : 1,
        stock_status: "available", dealership_id: dealershipId || null, owner_key: ownerKey, user_id: user.id,
      }).select("id").single();
      if (listingResult.error || !listingResult.data?.id) throw listingResult.error || new Error("The vehicle listing could not be created.");
      const listingId = String(listingResult.data.id); createdListingId = listingId;

      if (vehicleCategory === "truck") {
        const detailsResult = await supabase.from("truck_listing_details").insert({
          listing_id: listingId, user_id: user.id, vehicle_year: year, brand, model: modelName, body_type: bodyType,
          transmission, fuel_type: fuelType, axle_configuration: axleConfiguration,
          registration_number: registrationNumber.trim().toUpperCase(), vin: vin.trim().toUpperCase(), engine_number: engineNumber.trim().toUpperCase(),
          odometer_km: Number(odometerKm), gvm_kg: gvmKg ? Number(gvmKg) : null, payload_kg: payloadKg ? Number(payloadKg) : null,
          reference_image_url: referenceImage?.imageUrl || null, reference_image_source: referenceImage?.sourceUrl || null,
          factory_transmissions: selectedModel?.transmissions || [], specification_status: transmissionCheck?.requiresModificationProof ? "modified_pending_review" : "catalogue_match",
        });
        if (detailsResult.error) throw detailsResult.error;
      }

      const verificationResult = await supabase.from("vehicle_verifications").insert({
        listing_id: listingId, user_id: user.id, id_document_path: idPath, licence_document_path: licencePath,
        registration_document_path: registrationPath, ownership_document_path: ownershipPath, roadworthy_document_path: roadworthyPath,
        operating_licence_document_path: operatingLicencePath, modification_document_path: modificationProofPath,
        dealership_application: sellerType === "dealership" && !dealerPost,
        dealership_name: sellerType === "dealership" ? dealershipName.trim() : null,
        company_registration_number: sellerType === "dealership" && !dealerPost ? companyRegistrationNumber.trim().toUpperCase() : null,
        tax_number: sellerType === "dealership" && !dealerPost ? taxNumber.trim().toUpperCase() : null,
        company_registration_document_path: companyRegistrationPath, tax_document_path: taxDocumentPath,
        business_address_document_path: businessAddressPath, representative_authority_document_path: representativeAuthorityPath, status: "pending",
      });
      if (verificationResult.error) throw verificationResult.error;

      const owned = getOwnedJobKeys(); owned[listingId] = ownerKey; setOwnedJobKeys(owned);
      window.dispatchEvent(new Event("loadlink-account-state-changed"));
      await recordUserActivity("vehicle_listing_posted", { entityType: "listing", entityId: listingId, metadata: { title: title.trim(), category: vehicleCategory, dealershipId: dealershipId || null } }).catch(() => undefined);
      await syncAccountState().catch(() => undefined);
      setSaving(false); setSubmissionSuccess(true);
      window.setTimeout(() => router.push(dealershipId ? "/dealer?posted=vehicle" : "/my-posts?posted=vehicle"), 1800);
    } catch (error) {
      if (createdListingId) {
        try { await supabase.rpc("delete_my_listing", { p_listing_id: createdListingId, p_owner_key: createdOwnerKey }); } catch {}
      }
      setMessage(error instanceof Error ? error.message : "The vehicle listing could not be submitted.");
      setSaving(false);
    }
  }

  if (!authReady) return <main className="min-h-screen bg-black text-white"><LoadLinkLoading /></main>;

  const surface = darkMode ? "border-white/10 bg-[#101010] text-white" : "border-black/10 bg-white text-black";
  const muted = darkMode ? "text-white/55" : "text-black/55";
  const inputClass = `h-14 w-full rounded-xl border px-4 font-semibold outline-none focus:border-[#f6b800] ${darkMode ? "border-white/15 bg-[#171717] text-white placeholder:text-white/30" : "border-black/10 bg-[#faf8f2] text-black placeholder:text-black/35"}`;
  const textAreaClass = `${inputClass} min-h-32 py-4`;
  const categoryChosen = Boolean(vehicleCategory);
  const detailsReady = vehicleCategory === "truck" ? modelConfirmed : Boolean(vehicleSubtype && brand.trim() && modelName.trim());

  return (
    <main className={`min-h-screen transition-colors ${darkMode ? "bg-black text-white" : "bg-[#f4efe3] text-black"}`}>
      {saving ? <LoadLinkLoading /> : null}
      <SubmissionSuccess open={submissionSuccess} title="Vehicle submission sent" message={dealershipId ? "Your vehicle was added to the dealership inventory and submitted for review." : "Your vehicle and verification documents were submitted securely."} />
      <Header darkMode={darkMode} sellerType={sellerType} dealerPost={dealerPost} onToggleTheme={toggleTheme} onToggleSellerType={() => {
        if (dealerPost) return;
        if (sellerType === "dealership") {
          setSellerType("private");
          if (selectedPlan === "dealer") { setSelectedPlan(null); setPackageType("standard"); }
        } else {
          setSellerType("dealership");
        }
        setMessage("");
      }} />

      <section className="relative min-h-[300px] overflow-hidden border-b border-[#f6b800]/35 md:min-h-[360px]">
        <img src="/images/jobs/jobs-hero-fleet.jpg" alt="Commercial vehicles ready to be listed on LoadLink" className="absolute inset-0 h-full w-full scale-[1.03] object-cover object-center grayscale opacity-80 [mask-image:linear-gradient(to_bottom,black_0%,black_64%,transparent_100%)]" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/65 to-black/35 [mask-image:linear-gradient(to_bottom,black_0%,black_70%,transparent_100%)]" />
        <div className="relative mx-auto flex min-h-[300px] max-w-5xl flex-col justify-end px-5 pb-9 pt-20 text-white md:min-h-[360px]">
          <h1 className="max-w-3xl text-5xl font-black leading-[0.94] tracking-[-0.06em] md:text-7xl">{dealerPost ? `Add stock to ${dealershipName}` : "List your vehicle"}</h1>
          <p className="mt-4 max-w-xl text-base font-semibold leading-7 text-white/75">Choose your package, then select a truck, trailer or mobile unit and add the relevant details.</p>
        </div>
      </section>

      {!dealerPost ? (
        <section className={`border-b px-4 py-6 md:px-6 ${darkMode ? "border-white/10 bg-[#0b0b0b]" : "border-black/10 bg-white"}`}>
          <div className={`mx-auto max-w-6xl rounded-[24px] border p-5 md:flex md:items-center md:justify-between md:gap-8 md:p-6 ${darkMode ? "border-white/12 bg-[#111]" : "border-black/10 bg-[#faf8f2]"}`}>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#b88900]">Seller type</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.035em]">Are you a dealership?</h2>
              <p className={`mt-2 max-w-2xl text-sm font-semibold leading-6 ${muted}`}>Choose dealership to submit the required business documents and link approved stock to your public dealership page. Choose private seller for an individual listing.</p>
            </div>
            <div className="mt-5 grid shrink-0 grid-cols-2 gap-2 md:mt-0 md:min-w-[330px]">
              <button type="button" onClick={() => { setSellerType("private"); if (selectedPlan === "dealer") { setSelectedPlan(null); setPackageType("standard"); } setMessage(""); }} className={`min-h-12 rounded-xl border px-4 text-xs font-black uppercase tracking-[0.1em] transition ${sellerType === "private" ? "border-[#f6b800] bg-[#f6b800] text-black" : darkMode ? "border-white/15 bg-black text-white" : "border-black/15 bg-white text-black"}`}>Private seller</button>
              <button type="button" onClick={() => { setSellerType("dealership"); setMessage(""); }} className={`min-h-12 rounded-xl border px-4 text-xs font-black uppercase tracking-[0.1em] transition ${sellerType === "dealership" ? "border-[#f6b800] bg-[#f6b800] text-black" : darkMode ? "border-white/15 bg-black text-white" : "border-black/15 bg-white text-black"}`}>Yes, dealership</button>
            </div>
          </div>
        </section>
      ) : null}

      <BusinessPlans darkMode={darkMode} selectable selectedPlan={selectedPlan} onSelect={choosePlan} />

      {selectedPlan ? <form onSubmit={submitVehicle} className="mx-auto grid max-w-5xl gap-6 px-4 py-7 md:px-6 md:py-12">
        <section id="vehicle-type" className={`scroll-mt-24 overflow-hidden rounded-2xl border ${surface}`}>
          <SectionHeading step="01" title="Choose what you are listing" description="The form changes to show only the details relevant to the selected vehicle or mobile unit." />
          <div className="grid gap-3 p-5 sm:grid-cols-3 md:p-7">
            <CategoryButton label="Truck" description="Commercial trucks and tractor units" active={vehicleCategory === "truck"} onClick={() => chooseCategory("truck")} />
            <CategoryButton label="Trailer" description="All commercial trailer types" active={vehicleCategory === "trailer"} onClick={() => chooseCategory("trailer")} />
            <CategoryButton label="Mobile Unit" description="Mobile service and business units" active={vehicleCategory === "mobile_unit"} onClick={() => chooseCategory("mobile_unit")} />
          </div>
        </section>

        {categoryChosen ? <>
          <section className={`overflow-hidden rounded-2xl border ${surface}`}>
            <SectionHeading step="02" title={`${categoryLabel(vehicleCategory!)} identity`} description={vehicleCategory === "truck" ? "Select the registration year, manufacturer and exact truck model." : "Choose the unit type and enter the make and model exactly as shown on the registration papers."} />
            <div className="grid gap-5 p-5 md:grid-cols-3 md:p-7">
              {vehicleCategory !== "truck" ? <Field label={`${vehicleCategory === "trailer" ? "Trailer" : "Mobile unit"} type`}><select value={vehicleSubtype} onChange={(event) => { setVehicleSubtype(event.target.value); setBodyType(event.target.value); }} className={inputClass} required><option value="">Select type</option>{(vehicleCategory === "trailer" ? trailerTypes : mobileUnitTypes).map((item) => <option key={item}>{item}</option>)}</select></Field> : null}
              <Field label="Registration / model year"><select value={year} onChange={(event) => { setYear(Number(event.target.value)); setModelName(""); setModelConfirmed(false); }} className={inputClass}>{truckYears.map((item) => <option key={item} value={item}>{item}</option>)}</select></Field>
              <Field label="Make / manufacturer">{vehicleCategory === "truck" ? <select value={brand} onChange={(event) => { setBrand(event.target.value); setModelName(""); setModelConfirmed(false); }} className={inputClass} required><option value="">Choose manufacturer</option>{truckCatalog.map((item) => <option key={item.name} value={item.name}>{item.name}</option>)}</select> : <input value={brand} onChange={(event) => setBrand(event.target.value)} placeholder="Make or manufacturer" className={inputClass} required />}</Field>
              <Field label="Model">{vehicleCategory === "truck" ? <select value={modelName} onChange={(event) => { setModelName(event.target.value); setModelConfirmed(false); }} className={inputClass} disabled={!brand} required><option value="">Choose exact model</option>{availableModels.map((item) => <option key={item.name}>{item.name}</option>)}</select> : <input value={modelName} onChange={(event) => setModelName(event.target.value)} placeholder="Model name or number" className={inputClass} required />}</Field>
            </div>
            {vehicleCategory === "truck" ? <div className="border-t border-current/10 p-5 md:p-7"><button type="button" onClick={confirmSelectedModel} className="h-12 rounded-xl bg-[#f6b800] px-6 text-xs font-black uppercase text-black">Confirm truck model</button>{imageLoading ? <p className={`mt-3 text-sm ${muted}`}>Loading model reference…</p> : null}{referenceImage?.imageUrl ? <img src={referenceImage.imageUrl} alt={referenceImage.title || "Truck reference"} className="mt-4 aspect-[16/9] w-full max-w-xl rounded-xl object-cover" /> : null}</div> : <div className="border-t border-current/10 p-5 md:p-7"><button type="button" onClick={() => { setTitle(`${year} ${brand} ${modelName} ${vehicleSubtype}`.replace(/\s+/g, " ").trim()); setMessage(""); }} className="h-12 rounded-xl bg-[#f6b800] px-6 text-xs font-black uppercase text-black">Confirm vehicle details</button></div>}
          </section>

          {detailsReady ? <>
            <section className={`overflow-hidden rounded-2xl border ${surface}`}>
              <SectionHeading step="03" title="Vehicle details" description="Add the information buyers need before opening the full product view." />
              <div className="grid gap-5 p-5 md:grid-cols-2 md:p-7">
                <Field label="Listing title" wide><input value={title} onChange={(event) => setTitle(event.target.value)} className={inputClass} required /></Field>
                <Field label={vehicleCategory === "truck" ? "Body type" : "Type"}><select value={bodyType || vehicleSubtype} onChange={(event) => setBodyType(event.target.value)} className={inputClass}>{(vehicleCategory === "truck" ? truckBodyTypes : vehicleCategory === "trailer" ? trailerTypes : mobileUnitTypes).map((item) => <option key={item}>{item}</option>)}</select></Field>
                <Field label="Condition"><select value={condition} onChange={(event) => setCondition(event.target.value)} className={inputClass}><option>Excellent</option><option>Very good</option><option>Good</option><option>Fair</option><option>Needs attention</option></select></Field>
                <Field label="Transmission"><select value={transmission} onChange={(event) => setTransmission(event.target.value)} className={inputClass}>{gearboxOptions.map((item) => <option key={item}>{item}</option>)}</select></Field>
                <Field label="Fuel / power type"><input value={fuelType} onChange={(event) => setFuelType(event.target.value)} placeholder={vehicleCategory === "trailer" ? "Not applicable" : "Diesel, petrol, electric"} className={inputClass} /></Field>
                <Field label="Mileage / usage"><input type="number" min="0" value={odometerKm} onChange={(event) => setOdometerKm(event.target.value)} placeholder="Kilometres or usage reading" className={inputClass} required /></Field>
                <Field label="Previous owners"><input type="number" min="0" value={previousOwners} onChange={(event) => setPreviousOwners(event.target.value)} placeholder="0" className={inputClass} /></Field>
                <Field label="Service history"><select value={serviceHistory} onChange={(event) => setServiceHistory(event.target.value)} className={inputClass}><option>Full service history</option><option>Partial service history</option><option>No service history</option><option>Not applicable</option></select></Field>
                <Field label="Registration number"><input value={registrationNumber} onChange={(event) => setRegistrationNumber(event.target.value)} className={inputClass} required /></Field>
                <Field label="VIN / chassis number"><input value={vin} onChange={(event) => setVin(event.target.value)} className={inputClass} required /></Field>
                <Field label="Engine / serial number"><input value={engineNumber} onChange={(event) => setEngineNumber(event.target.value)} className={inputClass} /></Field>
                <Field label="Axle configuration"><input value={axleConfiguration} onChange={(event) => setAxleConfiguration(event.target.value)} placeholder="4x2, tandem, tri-axle" className={inputClass} /></Field>
                <Field label="GVM kg"><input type="number" min="0" value={gvmKg} onChange={(event) => setGvmKg(event.target.value)} className={inputClass} /></Field>
                <Field label="Payload / capacity kg"><input type="number" min="0" value={payloadKg} onChange={(event) => setPayloadKg(event.target.value)} className={inputClass} /></Field>
                <Field label="Price" wide><input value={rate} onChange={(event) => setRate(event.target.value)} placeholder="Example: 850000" inputMode="decimal" className={inputClass} required /></Field>
                <Field label="Location"><select value={city} onChange={(event) => setCity(event.target.value)} className={inputClass}>{cityOptions.map((item) => <option key={item}>{item}</option>)}</select></Field>
                <Field label="Description" wide><textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Describe the vehicle, maintenance, features, faults and anything a buyer should know." className={textAreaClass} required /></Field>
              </div>
            </section>

            <section className={`overflow-hidden rounded-2xl border ${surface}`}>
              <SectionHeading step="04" title="Photos and verification" description="Upload clear product photos and the critical documents required for review." />
              <div className="p-5 md:p-7"><label className="flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-[#f6b800]/50 bg-[#f6b800]/5 px-5 text-center"><span className="text-sm font-black uppercase">Upload vehicle photos</span><span className={`mt-2 text-xs ${muted}`}>Minimum 2 photos · up to {packageType === "pro" || packageType === "dealer" ? 15 : 8}</span><input type="file" accept="image/*" multiple onChange={handleVehiclePhotos} className="hidden" /></label>{vehiclePreviews.length ? <div className="mt-4 flex snap-x gap-3 overflow-x-auto pb-2">{vehiclePreviews.map((preview, index) => <img key={preview} src={preview} alt={`Vehicle preview ${index + 1}`} className="aspect-square w-32 shrink-0 snap-start rounded-xl object-cover" />)}</div> : null}</div>
              {sellerType === "dealership" && !dealerPost ? <div className="grid gap-4 border-t border-current/10 p-5 md:grid-cols-2 md:p-7"><Field label="Dealership name"><input value={dealershipName} onChange={(event) => setDealershipName(event.target.value)} className={inputClass} required /></Field><Field label="Company registration number"><input value={companyRegistrationNumber} onChange={(event) => setCompanyRegistrationNumber(event.target.value)} className={inputClass} required /></Field><Field label="SARS tax number"><input value={taxNumber} onChange={(event) => setTaxNumber(event.target.value)} className={inputClass} required /></Field><DocumentInput label="CIPC company registration" required file={documents.companyRegistration} onChange={(file) => setDocument("companyRegistration", file)} /><DocumentInput label="SARS tax document" required file={documents.taxDocument} onChange={(file) => setDocument("taxDocument", file)} /><DocumentInput label="Proof of business address" required file={documents.businessAddress} onChange={(file) => setDocument("businessAddress", file)} /><DocumentInput label="Representative authority" required file={documents.representativeAuthority} onChange={(file) => setDocument("representativeAuthority", file)} /></div> : null}
              <div className="grid gap-4 border-t border-current/10 p-5 md:grid-cols-2 md:p-7"><DocumentInput label="South African ID or passport" required file={documents.idDocument} onChange={(file) => setDocument("idDocument", file)} />{vehicleCategory === "truck" ? <DocumentInput label="Driver’s licence" required file={documents.driverLicence} onChange={(file) => setDocument("driverLicence", file)} /> : null}<DocumentInput label="Vehicle registration certificate" required file={documents.registrationPaper} onChange={(file) => setDocument("registrationPaper", file)} /><DocumentInput label="Proof of ownership or authority to list" required file={documents.ownershipProof} onChange={(file) => setDocument("ownershipProof", file)} /><DocumentInput label="Roadworthy certificate" file={documents.roadworthy} onChange={(file) => setDocument("roadworthy", file)} /><DocumentInput label="Operating licence" file={documents.operatingLicence} onChange={(file) => setDocument("operatingLicence", file)} />{transmissionCheck?.requiresModificationProof ? <DocumentInput label="Gearbox conversion paperwork" required file={documents.modificationProof} onChange={(file) => setDocument("modificationProof", file)} /> : null}</div>
            </section>

            <section className={`overflow-hidden rounded-2xl border ${surface}`}>
              <SectionHeading step="05" title="Contact and confirmation" description="Confirm the details before the product is added to LoadLink." />
              <div className="grid gap-5 p-5 md:grid-cols-2 md:p-7"><Field label={sellerType === "dealership" ? "Dealership / contact name" : "Owner / company name"}><input value={postedBy} onChange={(event) => setPostedBy(event.target.value)} className={inputClass} required /></Field><Field label="Contact number"><input value={contactNumber} onChange={(event) => setContactNumber(event.target.value)} placeholder="0821234567" className={inputClass} required /></Field><Field label="WhatsApp number — optional"><input value={whatsappNumber} onChange={(event) => setWhatsappNumber(event.target.value)} placeholder="0821234567" className={inputClass} /></Field><Field label="Selected plan"><div className={`${inputClass} flex items-center`}>{selectedPlan === "manual" ? "Manual listing — R15 per vehicle per day" : selectedPlan === "pro" ? "Pro listing — analytics enabled" : "Dealer package — dealership inventory"}</div></Field></div>
              <div className="grid gap-3 px-5 pb-5 md:px-7 md:pb-7"><CheckRow checked={confirmOwnership} onChange={setConfirmOwnership} label="I own this vehicle or have written authority from the owner to list it." /><CheckRow checked={confirmAccuracy} onChange={setConfirmAccuracy} label="I confirm that the details, mileage, ownership history and uploaded documents are accurate." /></div>
              <div className="border-t border-[#f6b800]/25 bg-black p-5 text-white md:p-7">{message ? <div className="mb-4 rounded-2xl border border-red-500/40 bg-red-500/10 p-4 text-sm font-bold leading-6 text-red-300">{message}</div> : null}<button type="submit" disabled={saving} className="flex h-14 w-full items-center justify-center rounded-2xl bg-[#f6b800] px-6 text-sm font-black uppercase tracking-[0.12em] text-black disabled:opacity-50">{saving ? "Submitting vehicle…" : dealershipId ? "Add to dealership inventory" : "Submit vehicle for verification"}</button><p className="mt-3 text-center text-xs leading-5 text-white/45">The product will appear in the dealership slider when linked to an approved dealership. Analytics remains available only on Pro listings.</p></div>
            </section>
          </> : null}
        </> : null}
      </form> : null}
    </main>
  );
}

function Header({ darkMode, sellerType, dealerPost, onToggleTheme, onToggleSellerType }: { darkMode: boolean; sellerType: SellerType; dealerPost: boolean; onToggleTheme: () => void; onToggleSellerType: () => void }) {
  return (
    <header className={`sticky top-0 z-50 border-b ${darkMode ? "border-white/10 bg-black" : "border-black/10 bg-white"}`}>
      <div className="grid h-20 grid-cols-[86px_1fr_142px] items-center px-3 sm:grid-cols-[120px_1fr_230px] sm:px-4">
        <div className="flex items-center gap-2"><SiteMenu darkMode={darkMode} /><AuthStatusButton darkMode={darkMode} /></div>
        <HomeLogoLink theme={darkMode ? "dark" : "light"} />
        <div className="flex items-center justify-end gap-2">
          {!dealerPost ? <button type="button" onClick={onToggleSellerType} className={`max-w-[88px] text-right text-[9px] font-black leading-3 underline decoration-[#f6b800] decoration-2 underline-offset-4 sm:max-w-none sm:text-xs sm:leading-4 ${darkMode ? "text-white" : "text-black"}`}>{sellerType === "dealership" ? "List as a private seller" : "Are you a dealership?"}</button> : null}
          <LoadLinkThemeToggle darkMode={darkMode} onToggle={onToggleTheme} />
        </div>
      </div>
    </header>
  );
}
function SectionHeading({ step, title, description }: { step: string; title: string; description: string }) { return <div className="border-b border-current/10 px-5 py-5 md:px-7"><p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#b88900]">{step}</p><h2 className="mt-2 text-3xl font-black tracking-[-0.04em]">{title}</h2><p className="mt-2 text-sm leading-6 opacity-55">{description}</p></div>; }
function Field({ label, children, wide = false }: { label: string; children: React.ReactNode; wide?: boolean }) { return <label className={wide ? "block md:col-span-2" : "block"}><span className="mb-2 block text-xs font-black uppercase tracking-[0.14em] text-[#b88900]">{label}</span>{children}</label>; }
function CategoryButton({ label, description, active, onClick }: { label: string; description: string; active: boolean; onClick: () => void }) { return <button type="button" onClick={onClick} className={`min-h-28 rounded-2xl border p-4 text-left transition ${active ? "border-[#f6b800] bg-[#f6b800] text-black" : "border-current/15"}`}><span className="text-lg font-black">{label}</span><span className={`mt-2 block text-xs leading-5 ${active ? "text-black/60" : "opacity-55"}`}>{description}</span></button>; }
function DocumentInput({ label, required = false, file, onChange }: { label: string; required?: boolean; file: File | null; onChange: (file: File | null) => void }) { return <label className="flex min-h-28 cursor-pointer flex-col justify-center rounded-2xl border border-[#f6b800]/35 bg-[#f6b800]/5 px-4 py-4"><span className="text-xs font-black uppercase tracking-[0.12em] text-[#b88900]">{label}{required ? " *" : ""}</span><span className="mt-2 truncate text-sm font-bold">{file ? file.name : "Choose image or PDF"}</span><span className="mt-1 text-[10px] opacity-45">JPG, PNG, WEBP or PDF · maximum 10 MB</span><input type="file" accept={acceptedDocuments} required={required && !file} onChange={(event) => onChange(event.target.files?.[0] || null)} className="hidden" /></label>; }
function CheckRow({ checked, onChange, label }: { checked: boolean; onChange: (value: boolean) => void; label: string }) { return <label className="flex cursor-pointer items-start gap-3 rounded-2xl border border-[#f6b800]/30 p-4"><input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} className="mt-1 h-5 w-5 accent-[#f6b800]" /><span className="text-sm font-semibold leading-6">{label}</span></label>; }
