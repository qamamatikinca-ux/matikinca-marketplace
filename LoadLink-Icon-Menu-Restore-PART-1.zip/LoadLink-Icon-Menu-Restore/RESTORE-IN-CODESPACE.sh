#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(git rev-parse --show-toplevel 2>/dev/null || true)"

if [ -z "$REPO_DIR" ]; then
  echo "ERROR: Open the LoadLink GitHub Codespace and run this script from inside the repository."
  exit 1
fi

cd "$REPO_DIR"

if [ "$(git branch --show-current)" != "main" ]; then
  git checkout main
fi

git pull --ff-only origin main

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_BRANCH="backup-before-icon-menu-restore-$STAMP"

git branch "$BACKUP_BRANCH"
git push origin "$BACKUP_BRANCH"

echo "Current website backed up to: $BACKUP_BRANCH"

echo "Restoring the approved icon-menu website source..."
rsync -a --delete "$SOURCE_DIR/" "$REPO_DIR/" \
  --exclude='.git/' \
  --exclude='.github/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='node_modules/' \
  --exclude='.next/' \
  --exclude='RESTORE-IN-CODESPACE.sh' \
  --exclude='RESTORE-NOTES.txt' \
  --exclude='*.log'

rm -rf .next
npm ci --no-audit --no-fund
npm run build

git add -A

if git diff --cached --quiet; then
  echo "No file changes were detected. The icon-menu version may already be restored."
  exit 0
fi

git commit -m "Restore approved LoadLink icon-menu website"
git push origin main

echo ""
echo "SUCCESS: The approved LoadLink icon-menu website was restored and pushed to main."
echo "Vercel should redeploy automatically."
echo "Backup branch: $BACKUP_BRANCH"
