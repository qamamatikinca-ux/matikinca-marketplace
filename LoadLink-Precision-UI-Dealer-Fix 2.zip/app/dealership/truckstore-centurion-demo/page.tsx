import { redirect } from "next/navigation";

export default function DealerDemoRedirect() {
  redirect("/dealership/loadlink-test-dealership");
}
