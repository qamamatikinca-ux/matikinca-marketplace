"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import HomeLogoLink from "@/components/HomeLogoLink";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";
import { formatListingRate } from "@/lib/formatCurrency";

type Profile = { id?: string; owner_user_id?: string; slug?: string; name?: string; display_name?: string; city?: string; province?: string; description?: string; follower_count?: number; verified?: boolean; public_visible?: boolean; logo_url?: string; cover_url?: string; contact_email?: string; };
type Listing = { id: string; title?: string; city?: string; rate?: string; photos?: string[]; description?: string; created_at?: string; };

const demoProfile: Profile = {
  slug: "loadlink-test-dealership",
  name: "LoadLink Test Dealership",
  display_name: "Centurion Commercial Truck Centre",
  city: "Centurion",
  province: "Gauteng",
  description: "Dealer-package preview inside the main LoadLink website. The signed-in dealership owner manages this profile from the same LoadLink account.",
  follower_count: 0,
  verified: true,
  public_visible: true,
  cover_url: "https://tso-assets-prd.s3.amazonaws.com/_processed_/6/0/csm_Landingpage_Standorte_f28a99295a.jpg",
};

const demoListings: Listing[] = [
  { id: "demo-1", title: "Mercedes-Benz Actros 2645", city: "Centurion", rate: "R1 695 000", photos: ["/images/truck-1.jpg"], description: "Dealer stock example with full vehicle details, contact and enquiry options." },
  { id: "demo-2", title: "Volvo FH 440 Globetrotter", city: "Centurion", rate: "Request a quote", photos: ["/images/truck-2.jpg"], description: "Commercial tractor unit available through the dealership profile." },
  { id: "demo-3", title: "Scania R-series 460", city: "Centurion", rate: "R1 250 000", photos: ["/images/truck-3.jpg"], description: "Heavy-duty long-haul vehicle example." },
  { id: "demo-4", title: "MAN TGS 26.440", city: "Centurion", rate: "R985 000", photos: ["/images/jobs/job-card-1.jpg"], description: "Dealer inventory post shown in the LoadLink profile grid." },
  { id: "demo-5", title: "Mercedes-Benz Axor 3340", city: "Centurion", rate: "R875 000", photos: ["/images/jobs/job-card-2.jpg"], description: "Vehicle details open after tapping the grid image." },
  { id: "demo-6", title: "DAF XF 480", city: "Centurion", rate: "R1 420 000", photos: ["/images/jobs/job-card-3.jpg"], description: "Example dealer package stock listing." },
];

const localFallbacks = ["/images/truck-1.jpg", "/images/truck-2.jpg", "/images/truck-3.jpg", "/images/jobs/job-card-1.jpg", "/images/jobs/job-card-2.jpg", "/images/jobs/job-card-3.jpg"];

export default function DealershipProfilePage() {
  const params = useParams<{ slug: string }>();
  const slug = String(params?.slug || "");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [selected, setSelected] = useState<Listing | null>(null);
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => {
    let active = true;
    async function load() {
      if (!isSupabaseConfigured) {
        if (active && slug === demoProfile.slug) { setProfile(demoProfile); setListings(demoListings); }
        return;
      }
      const [{ data: userData }, profileResult] = await Promise.all([
        supabase.auth.getUser(),
        supabase.from("dealership_profiles").select("*").eq("slug", slug).maybeSingle(),
      ]);
      if (!active) return;
      const found = profileResult.data as Profile | null;
      const effective = found || (slug === demoProfile.slug ? demoProfile : null);
      setProfile(effective);
      setIsOwner(Boolean(found?.owner_user_id && found.owner_user_id === userData.user?.id));
      if (found?.id) {
        let result = await supabase.from("job_listings").select("id,title,city,rate,photos,description,created_at").eq("dealership_id", found.id).eq("moderation_status", "approved").order("created_at", { ascending: false }).limit(60);
        if (result.error && /column|schema cache/i.test(result.error.message)) result = await supabase.from("job_listings").select("id,title,city,rate,photos,description,created_at").eq("user_id", found.owner_user_id).order("created_at", { ascending: false }).limit(60);
        if (!result.error && result.data?.length) setListings(result.data as Listing[]); else if (slug === demoProfile.slug) setListings(demoListings);
      } else if (slug === demoProfile.slug) setListings(demoListings);
    }
    void load();
    return () => { active = false; };
  }, [slug]);

  const visibleListings = useMemo(() => listings.length ? listings : demoListings, [listings]);
  if (!profile) return <main className="min-h-screen bg-black text-white"><div className="mx-auto max-w-xl px-5 py-24 text-center"><h1 className="text-3xl font-black">Dealership profile unavailable</h1><Link href="/" className="mt-6 inline-flex border border-[#f6b800] px-5 py-3 font-black text-[#f6b800]">Return home</Link></div></main>;

  return (
    <main className="min-h-screen bg-white text-black">
      <header className="sticky top-0 z-40 border-b border-black/10 bg-white/95 backdrop-blur">
        <div className="grid h-16 grid-cols-[64px_1fr_92px] items-center px-3"><Link href="/" className="text-sm font-black">Back</Link><HomeLogoLink theme="light" />{isOwner ? <Link href="/dealer-dashboard" className="justify-self-end text-xs font-black">Dashboard</Link> : <span />}</div>
      </header>

      <section className="mx-auto max-w-4xl px-4 pb-4 pt-6">
        <div className="grid grid-cols-[96px_1fr] items-center gap-5 md:grid-cols-[150px_1fr]">
          <div className="aspect-square overflow-hidden rounded-full border-4 border-[#f6b800] bg-black p-1">
            <img src={profile.logo_url || profile.cover_url || demoProfile.cover_url} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = "/images/loadlink-logo.png"; }} alt={profile.display_name || profile.name || "Dealership"} className="h-full w-full rounded-full object-cover" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-3"><h1 className="text-2xl font-black md:text-3xl">{profile.display_name || profile.name}</h1>{profile.verified ? <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#f6b800] text-xs font-black">✓</span> : null}</div>
            <div className="mt-4 grid max-w-md grid-cols-3 gap-4 text-center"><div><strong className="block text-lg">{visibleListings.length}</strong><span className="text-xs text-black/55">posts</span></div><div><strong className="block text-lg">{profile.follower_count || 0}</strong><span className="text-xs text-black/55">followers</span></div><div><strong className="block text-lg">Dealer</strong><span className="text-xs text-black/55">package</span></div></div>
          </div>
        </div>
        <div className="mt-5"><p className="font-black">{profile.name || profile.display_name}</p><p className="mt-1 text-sm leading-6 text-black/65">{profile.description}</p><p className="mt-1 text-sm font-semibold">{[profile.city, profile.province].filter(Boolean).join(", ")}</p></div>
        <div className="mt-4 grid grid-cols-2 gap-2"><button className="h-10 rounded-lg bg-black text-sm font-black text-white">Follow</button><Link href="/messages" className="flex h-10 items-center justify-center rounded-lg border border-black/15 text-sm font-black">Message</Link></div>
      </section>

      <section className="mx-auto max-w-4xl border-t border-black/10">
        <div className="grid grid-cols-3 gap-[2px] bg-white">
          {visibleListings.map((item, index) => <button key={item.id} type="button" onClick={() => setSelected(item)} className="group relative aspect-square overflow-hidden bg-black/5"><img src={item.photos?.[0] || localFallbacks[index % localFallbacks.length]} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = localFallbacks[index % localFallbacks.length]; }} alt={item.title || "Truck listing"} className="h-full w-full object-cover transition duration-300 group-hover:scale-105" /><span className="absolute inset-0 bg-black/0 transition group-hover:bg-black/10" /></button>)}
        </div>
      </section>

      {selected ? <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm md:items-center md:p-5" onClick={() => setSelected(null)}><article className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white md:rounded-3xl" onClick={(e) => e.stopPropagation()}><div className="relative aspect-square bg-black/5"><img src={selected.photos?.[0] || "/images/truck-1.jpg"} onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = "/images/truck-1.jpg"; }} alt={selected.title || "Truck"} className="h-full w-full object-cover" /><button onClick={() => setSelected(null)} className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full bg-black/75 text-xl text-white">×</button></div><div className="p-5"><h2 className="text-2xl font-black">{selected.title || "Commercial truck"}</h2><p className="mt-1 text-sm text-black/55">{selected.city || profile.city}</p><p className="mt-4 text-2xl font-black text-[#9d7300]">{formatListingRate(selected.rate)}</p>{selected.description ? <p className="mt-4 text-sm leading-6 text-black/65">{selected.description}</p> : null}<Link href={`/jobs?portal=asset#job-${selected.id}`} className="mt-5 flex h-12 items-center justify-center rounded-xl bg-black text-sm font-black text-[#f6b800]">View full listing</Link></div></article></div> : null}
    </main>
  );
}
