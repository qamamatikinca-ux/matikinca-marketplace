"use client";

import Link from "next/link";

export type BusinessPlanId = "manual" | "pro" | "dealer";

type Plan = {
  id: BusinessPlanId;
  name: string;
  price: string;
  billing: string;
  description: string;
  features: string[];
  highlight?: boolean;
  badge?: string;
};

const plans: Plan[] = [
  {
    id: "manual",
    name: "Manual listing",
    price: "R15",
    billing: "per vehicle, per day",
    description: "A simple pay-as-you-go option for private sellers and occasional listings.",
    features: ["One vehicle listing", "Up to 5 vehicle photos", "50 chat messages per day", "Standard search placement"],
  },
  {
    id: "pro",
    name: "Pro",
    price: "Monthly",
    billing: "subscription",
    description: "For active operators who need stronger visibility and listing performance data.",
    features: ["More active listings", "Up to 15 photos per vehicle", "Listing analytics", "Higher search visibility", "Priority support"],
    highlight: true,
    badge: "Best for operators",
  },
  {
    id: "dealer",
    name: "Dealer",
    price: "R2 999",
    billing: "per month",
    description: "A complete branded dealership showroom with inventory and lead-management tools.",
    features: ["Daily listing fees included", "Public dealership profile", "Instagram-style inventory grid", "Followers and updates", "Lead and staff management", "Dealer analytics"],
    badge: "Full dealership",
  },
];

type BusinessPlansProps = {
  darkMode?: boolean;
  compact?: boolean;
  selectedPlan?: BusinessPlanId | null;
  onSelect?: (plan: BusinessPlanId) => void;
};

export default function BusinessPlans({ darkMode = false, compact = false, selectedPlan = null, onSelect }: BusinessPlansProps) {
  return (
    <section className={compact ? "" : `px-4 py-10 md:px-6 ${darkMode ? "bg-black text-white" : "bg-[#f4efe3] text-black"}`}>
      <div className="mx-auto max-w-6xl">
        {!compact ? (
          <div className="mb-7 max-w-3xl">
            <h2 className="text-4xl font-black tracking-[-0.045em] md:text-6xl">Choose how you want to list.</h2>
            <p className={`mt-4 max-w-2xl text-sm leading-7 md:text-base ${darkMode ? "text-white/60" : "text-black/60"}`}>Select one package first. The truck form will open immediately after your choice.</p>
          </div>
        ) : null}

        <div className="grid gap-4 lg:grid-cols-3">
          {plans.map((plan) => {
            const selected = selectedPlan === plan.id;
            const cardClass = selected
              ? "border-[#f6b800] bg-black text-white shadow-[0_22px_65px_rgba(184,137,0,.22)]"
              : plan.highlight
                ? "border-[#f6b800]/70 bg-black text-white shadow-[0_18px_50px_rgba(184,137,0,.14)]"
                : darkMode
                  ? "border-white/10 bg-[#0d0d0d] text-white"
                  : "border-black/10 bg-white text-black";

            return (
              <article key={plan.id} className={`relative flex min-h-full flex-col overflow-hidden rounded-[24px] border p-5 md:p-6 ${cardClass}`}>
                <div className="flex items-start justify-between gap-3">
                  {plan.badge ? <span className={`inline-flex rounded-full px-3 py-1 text-[9px] font-black uppercase tracking-[0.14em] ${plan.highlight || selected ? "bg-[#f6b800] text-black" : "bg-[#f6b800]/15 text-[#9a7100]"}`}>{plan.badge}</span> : <span />}
                  {selected ? <span className="rounded-full border border-[#f6b800] px-3 py-1 text-[9px] font-black uppercase tracking-[0.14em] text-[#f6b800]">Selected</span> : null}
                </div>
                <h3 className="mt-4 text-2xl font-black tracking-[-0.035em]">{plan.name}</h3>
                <div className="mt-4 flex items-end gap-2">
                  <span className="text-4xl font-black tracking-[-0.05em]">{plan.price}</span>
                  <span className={`pb-1 text-xs font-bold ${plan.highlight || selected ? "text-white/50" : darkMode ? "text-white/45" : "text-black/45"}`}>{plan.billing}</span>
                </div>
                <p className={`mt-4 min-h-16 text-sm leading-6 ${plan.highlight || selected ? "text-white/65" : darkMode ? "text-white/55" : "text-black/55"}`}>{plan.description}</p>
                <div className={`my-5 h-px ${plan.highlight || selected ? "bg-white/10" : darkMode ? "bg-white/10" : "bg-black/10"}`} />
                <ul className="space-y-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3 text-sm font-semibold leading-5">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#f6b800] text-[11px] font-black text-black">✓</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-6">
                  {onSelect ? (
                    <button type="button" onClick={() => onSelect(plan.id)} className={`flex h-12 w-full items-center justify-center rounded-xl text-xs font-black uppercase tracking-[0.13em] ${selected ? "bg-[#f6b800] text-black" : plan.highlight ? "bg-[#f6b800] text-black" : "border border-[#f6b800] text-[#a87900]"}`}>
                      {selected ? "Package selected" : `Choose ${plan.name}`}
                    </button>
                  ) : (
                    <Link href={`/list-your-truck?package=${plan.id}`} className={`flex h-12 items-center justify-center rounded-xl text-xs font-black uppercase tracking-[0.13em] ${plan.highlight ? "bg-[#f6b800] text-black" : "border border-[#f6b800] text-[#a87900]"}`}>
                      Choose this option
                    </Link>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
