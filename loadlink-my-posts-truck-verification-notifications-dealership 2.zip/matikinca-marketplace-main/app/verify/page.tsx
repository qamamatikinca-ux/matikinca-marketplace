"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";

import HomeLogoLink from "@/components/HomeLogoLink";
import SubmissionSuccess from "@/components/SubmissionSuccess";
import { isSupabaseConfigured, supabase } from "@/lib/supabaseClient";

type Step = "phone" | "otp" | "documents" | "done";

export default function VerifyPage() {
  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("+27");
  const [token, setToken] = useState("");
  const [fullName, setFullName] = useState("");
  const [idType, setIdType] = useState("south_african_id");
  const [last4, setLast4] = useState("");
  const [idFile, setIdFile] = useState<File | null>(null);
  const [selfie, setSelfie] = useState<File | null>(null);
  const [company, setCompany] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (!data.user) setMessage("Sign in before starting verification.");
    });
  }, []);

  async function sendOtp() {
    setBusy(true);
    setMessage("");
    if (!isSupabaseConfigured) {
      setMessage("Supabase is not connected.");
      setBusy(false);
      return;
    }
    const clean = phone.replace(/\s/g, "");
    const { error } = await supabase.auth.signInWithOtp({ phone: clean });
    setBusy(false);
    if (error) {
      setMessage(error.message);
      return;
    }
    setStep("otp");
    setMessage("Verification code sent by SMS.");
  }

  async function verifyOtp() {
    setBusy(true);
    setMessage("");
    const { error } = await supabase.auth.verifyOtp({ phone: phone.replace(/\s/g, ""), token, type: "sms" });
    setBusy(false);
    if (error) {
      setMessage(error.message);
      return;
    }
    setStep("documents");
    setMessage("Number verified. Complete the identity check below.");
  }

  async function upload(file: File, userId: string, label: string) {
    const ext = file.name.split(".").pop()?.toLowerCase() || "bin";
    const path = `${userId}/${label}-${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("verification-documents").upload(path, file, { upsert: false });
    if (error) throw error;
    return path;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!idFile || !selfie) {
      setMessage("Add your identity document and a clear selfie.");
      return;
    }

    setBusy(true);
    setMessage("");
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Sign in before submitting.");

      const [idPath, selfiePath, companyPath] = await Promise.all([
        upload(idFile, user.id, "identity"),
        upload(selfie, user.id, "selfie"),
        company ? upload(company, user.id, "company") : Promise.resolve(null),
      ]);

      const payload = {
        user_id: user.id,
        full_name: fullName.trim(),
        phone: phone.replace(/\s/g, ""),
        id_type: idType,
        id_number_last4: last4,
        id_document_path: idPath,
        selfie_path: selfiePath,
        company_document_path: companyPath,
        status: "pending",
      };

      const { error } = await supabase.from("verification_requests").upsert(payload, { onConflict: "user_id" });
      if (error) throw error;
      setStep("done");
      setSubmissionSuccess(true);
      window.setTimeout(() => setSubmissionSuccess(false), 2100);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Submission failed.");
    } finally {
      setBusy(false);
    }
  }

  const input = "mt-2 h-12 w-full border border-black/15 bg-white px-4 text-black outline-none focus:border-[#b88900]";

  return (
    <main className="min-h-screen bg-[#fff6dc] px-5 py-8 text-black">
      <SubmissionSuccess open={submissionSuccess} title="Verification sent" />
      <div className="mx-auto max-w-xl">
        <header className="flex items-center justify-between">
          <HomeLogoLink />
          <Link href="/verification-status" className="text-sm font-black">Check status</Link>
        </header>

        <section className="mt-8 border border-black/10 bg-white p-6 shadow-xl">
          <p className="text-xs font-black uppercase tracking-[.25em] text-[#9a6a00]">Account verification</p>
          <h1 className="mt-3 text-3xl font-black">Verify your identity</h1>
          <div className="mt-5 border border-[#d4a532] bg-[#fff6dc] p-4 text-sm font-semibold leading-6">
            <strong>Verification usually takes a few minutes when a reviewer is available.</strong> You can leave this page after submitting. Your status updates automatically as soon as a decision is made.
          </div>

          {step === "phone" ? (
            <div className="mt-6">
              <label className="text-sm font-black">South African cellphone number<input className={input} value={phone} onChange={(event) => setPhone(event.target.value)} inputMode="tel" /></label>
              <button disabled={busy} onClick={sendOtp} className="mt-5 h-12 w-full bg-black font-black text-[#f6b800] disabled:opacity-50">{busy ? "Sending code" : "Send verification code"}</button>
            </div>
          ) : null}

          {step === "otp" ? (
            <div className="mt-6">
              <label className="text-sm font-black">SMS verification code<input className={input} value={token} onChange={(event) => setToken(event.target.value)} inputMode="numeric" maxLength={6} /></label>
              <button disabled={busy} onClick={verifyOtp} className="mt-5 h-12 w-full bg-black font-black text-[#f6b800] disabled:opacity-50">{busy ? "Checking code" : "Verify number"}</button>
            </div>
          ) : null}

          {step === "documents" ? (
            <form onSubmit={submit} className="mt-6 space-y-5">
              <label className="block text-sm font-black">Full legal name<input required className={input} value={fullName} onChange={(event) => setFullName(event.target.value)} /></label>
              <label className="block text-sm font-black">Document type<select className={input} value={idType} onChange={(event) => setIdType(event.target.value)}><option value="south_african_id">South African ID</option><option value="passport">Passport</option></select></label>
              <label className="block text-sm font-black">Last four digits of ID or passport<input required className={input} value={last4} onChange={(event) => setLast4(event.target.value.replace(/\D/g, "").slice(0, 4))} inputMode="numeric" /></label>
              <FileField label="Identity document" required onChange={setIdFile} />
              <FileField label="Clear selfie showing your face" required onChange={setSelfie} />
              <FileField label="Company registration document (optional)" onChange={setCompany} />
              <button disabled={busy} className="h-12 w-full bg-[#f6b800] font-black text-black disabled:opacity-50">{busy ? "Submitting securely" : "Submit for verification"}</button>
            </form>
          ) : null}

          {step === "done" ? (
            <div className="mt-7">
              <h2 className="text-2xl font-black">Submission received</h2>
              <p className="mt-3 leading-7 text-black/65">Your documents are private and your application is now pending review. The status page checks for updates automatically.</p>
              <Link href="/verification-status" className="mt-6 flex h-12 items-center justify-center bg-black font-black text-[#f6b800]">View verification status</Link>
            </div>
          ) : null}

          {message ? <p className="mt-5 border border-black/10 bg-black/5 p-4 text-sm font-semibold">{message}</p> : null}
        </section>
      </div>
    </main>
  );
}

function FileField({ label, required, onChange }: { label: string; required?: boolean; onChange: (file: File | null) => void }) {
  return (
    <label className="block text-sm font-black">
      {label}
      <input required={required} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(event) => onChange(event.target.files?.[0] || null)} className="mt-2 block w-full border border-black/15 bg-white p-3 text-sm font-semibold file:mr-3 file:border-0 file:bg-black file:px-3 file:py-2 file:font-black file:text-[#f6b800]" />
    </label>
  );
}
