export { default } from "../list-your-truck/page";
