LOADLINK UPDATE 13 — CHANGED FILES ONLY

This package does NOT contain the whole website.

INSTALLATION
1. Extract this ZIP.
2. Upload the included app and components folders into the root of your existing GitHub repository.
3. Choose Replace/Overwrite when GitHub asks about files with the same names.
4. Commit the changes to the main branch.
5. Vercel should redeploy automatically.

FILES INCLUDED
- app/dealer/page.tsx
- app/dealership/[slug]/page.tsx
- app/list-your-truck/page.tsx
- app/list-your-vehicle/page.tsx
- components/SiteMenu.tsx

No environment variables, Supabase keys, authentication settings, existing listings, or chat data are included or replaced.
